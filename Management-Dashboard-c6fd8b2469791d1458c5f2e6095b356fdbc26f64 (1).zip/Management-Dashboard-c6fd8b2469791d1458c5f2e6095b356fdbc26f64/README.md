# Student Heights Management Workspace

The root page (`/`) and `/demo` open the standalone, offline preview. Staff can also choose **Preview the management workspace** from `/login` without signing in or connecting Supabase. These preview routes do not authenticate users or access live applications, residences, documents, or management actions. Anyone who can access the hosted site can open this preview, so keep its content fictional until authentication and security are configured. All records and process actions are fictional and local to the page; processing shows an on-screen confirmation but changes no live records. Applicant names open fictional details with three illustrative document previews and print controls; these are not actual uploaded student documents. Use **Exit preview** to open `/login`, which loads the protected management sign-in and its Supabase integration.

## Dormant Supabase integration and security

Supabase settings are only used by the protected management sign-in at `/login`; they are not needed for the offline preview.

The Vercel function at `api/config.js` reads `SUPABASE_URL` and `SUPABASE_PUBLISHABLE_KEY` from the deployment environment and returns only those browser-safe settings. Configure both variables for Production and Preview in Vercel:

- `SUPABASE_URL`: `https://iklpdshgmrtkkufwcbfv.supabase.co`
- `SUPABASE_PUBLISHABLE_KEY`: the publishable key (or legacy anon key) belonging to that same Supabase project

Never configure a service-role key for this dashboard. Never place it in browser code, a checked-in configuration file, or a public Vercel variable. The publishable key is not a substitute for RLS; application and storage access still relies on the signed-in user's permissions.

The dashboard allows management data access only when the authenticated user's trusted `app_metadata.role` is exactly `management`. The UI does not provide registration or role assignment. Provision the account in Supabase Auth, then use a trusted server-side/admin process to assign its `app_metadata` role. Do not put an admin/service-role credential into either website. RLS and `management_set_application_status(p_application_id, p_status)` remain the database enforcement boundary; decisions are sent only through that RPC.

Documents are fetched through the authenticated Supabase Storage client from the private `application-documents` bucket. The dashboard does not create public or permanent URLs.

## Student website configuration blocker

The deployed student website's public `config.js` was observed to point at a different Supabase project. Its `supabaseUrl` must be changed to `https://iklpdshgmrtkkufwcbfv.supabase.co`, and `supabasePublishableKey` must be the publishable/anon key from that same project. Do not reuse a key from the other project. This workspace does not contain the student website source, so its registration, verification, application, and upload code has not been modified or verified here.

## Deploy the offline preview to Vercel

1. Import the existing management-dashboard project/source into Vercel. Set its Root Directory to this workspace's project root. Keep `vercel.json` in the deployed project so Vercel serves the app shell for `/login` and `/demo`; without these rewrites, opening **Exit preview** at `/login` returns Vercel's 404 page.
2. Use the **Other** framework preset, no build command, and `.` as the output directory. Vercel will serve the static assets and deploy `api/config.js` as a function; no local Node.js installation is needed to edit or preview the static pages.
3. No Supabase environment variables or Auth redirect settings are needed for the offline preview.

For the student site, set its Supabase URL and publishable key to the same project in that project's own deployment configuration. Its source and Vercel project settings are not part of this workspace, so a student-site deployment cannot be performed from here.

## Local Windows preview

Set the same browser-safe settings in PowerShell, then start the included static server:

```powershell
$env:SUPABASE_URL = "https://iklpdshgmrtkkufwcbfv.supabase.co"
$env:SUPABASE_PUBLISHABLE_KEY = "<publishable key for this project>"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\server.ps1
```

Open `http://localhost:3000/`. The server's `/api/config` endpoint emits only the URL and publishable key. The local server supports the fictional preview at `http://localhost:3000/demo` as a separate experience.

## End-to-end verification

1. In the deployed dashboard, confirm the `/api/config` response succeeds and points to the expected Supabase project; never share or log the publishable key.
2. Sign in with a pre-provisioned management account. Verify that a wrong password gets a friendly credentials message and that the authorized account loads real applications and residences. Confirm a non-management account is denied.
3. Use **Forgot your password?** with the staff email. Confirm the recovery email opens the deployed dashboard, permits a new password, and returns to the management workspace. Test only on an origin included in Supabase's allowed redirect URLs.
4. Confirm application details and counts. Open documents through authenticated private storage access and change status to `under_review`, `approved`, or `rejected`; verify the RPC result and refreshed status.
5. In the student website (after its source/configuration is corrected), submit a test application and confirm it appears in the dashboard.

This workspace has not been tested against live student or management accounts. Database policies and bucket settings are relied on as supplied and have not been independently inspected from this source workspace. Vercel project environment settings are outside this source workspace and must be verified in the Vercel dashboard.
