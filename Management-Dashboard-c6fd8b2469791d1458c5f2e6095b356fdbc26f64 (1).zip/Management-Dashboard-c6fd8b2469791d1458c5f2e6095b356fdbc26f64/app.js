const app = document.querySelector("#app");
const path = window.location.pathname.replace(/\/+$/, "") || "/";
const isDemo = path === "/" || path === "/demo" || window.location.hash === "#demo";

let currentTheme = "light";
let demoApplicationQuery = "";
let demoActionMessage = "";

try {
  const savedTheme = window.localStorage.getItem("vsh-theme");
  if (savedTheme === "dark" || savedTheme === "light") {
    currentTheme = savedTheme;
  }
} catch (error) {
  console.warn("Unable to read the saved display theme.", error);
}
document.documentElement.dataset.theme = currentTheme;

function renderThemeToggle() {
  const isDark = currentTheme === "dark";
  return `<button class="theme-toggle" type="button" aria-label="Switch to ${isDark ? "bright" : "dark"} mode" aria-pressed="${isDark}">
    <span class="theme-icon" aria-hidden="true">${isDark ? "☀" : "☾"}</span><span>${isDark ? "Bright mode" : "Dark mode"}</span>
  </button>`;
}

function bindThemeToggle() {
  document.querySelectorAll(".theme-toggle").forEach((button) => {
    button.addEventListener("click", () => {
      currentTheme = currentTheme === "dark" ? "light" : "dark";
      document.documentElement.dataset.theme = currentTheme;
      try {
        window.localStorage.setItem("vsh-theme", currentTheme);
      } catch (error) {
        console.warn("Unable to save the display theme.", error);
      }

      document.querySelectorAll(".theme-toggle").forEach((toggle) => {
        const isDark = currentTheme === "dark";
        toggle.setAttribute("aria-label", `Switch to ${isDark ? "bright" : "dark"} mode`);
        toggle.setAttribute("aria-pressed", String(isDark));
        toggle.innerHTML = `<span class="theme-icon" aria-hidden="true">${isDark ? "☀" : "☾"}</span><span>${isDark ? "Bright mode" : "Dark mode"}</span>`;
      });
    });
  });
}

const brandMark = `
  <span class="brand-logo">
    <img src="/images/Logo.jpg" alt="Student Heights accommodation logo">
  </span>`;

const logo = `
  <a class="brand" href="/login" aria-label="Vaal Student Hive staff workspace">
    ${brandMark}
    <span class="brand-copy"><strong>VAAL STUDENT HIVE</strong><span>STAFF WORKSPACE</span></span>
  </a>`;

const demoApplications = [
  { name: "Amara Nkosi", student: "Sample student • 2026", ref: "DEMO-26041", residence: "18On Demeter", submitted: "18 Oct 2026", status: "Pending", documents: [{ name: "Identity document.pdf", summary: "Example identity document for the fictional preview applicant." }, { name: "Proof of registration.pdf", summary: "Example 2026 registration confirmation for the fictional preview applicant." }, { name: "Proof of funding.pdf", summary: "Example funding confirmation for the fictional preview applicant." }] },
  { name: "Liam Dlamini", student: "Sample student • 2026", ref: "DEMO-26040", residence: "4Anthenia Student Accomodation", submitted: "17 Oct 2026", status: "Under review", documents: [{ name: "Identity document.pdf", summary: "Example identity document for the fictional preview applicant." }, { name: "Proof of registration.pdf", summary: "Example 2026 registration confirmation for the fictional preview applicant." }, { name: "Proof of funding.pdf", summary: "Example funding confirmation for the fictional preview applicant." }] },
  { name: "Zanele Mokoena", student: "Sample student • 2026", ref: "DEMO-26039", residence: "Bovua@10Bellona", submitted: "16 Oct 2026", status: "Approved", documents: [{ name: "Identity document.pdf", summary: "Example identity document for the fictional preview applicant." }, { name: "Proof of registration.pdf", summary: "Example 2026 registration confirmation for the fictional preview applicant." }, { name: "Proof of funding.pdf", summary: "Example funding confirmation for the fictional preview applicant." }] },
  { name: "Thabo Molefe", student: "Sample student • 2026", ref: "DEMO-26038", residence: "Koeneng Student Accomodation", submitted: "15 Oct 2026", status: "Correction requested", documents: [{ name: "Identity document.pdf", summary: "Example identity document for the fictional preview applicant." }, { name: "Proof of registration.pdf", summary: "Example 2026 registration confirmation for the fictional preview applicant." }, { name: "Proof of funding.pdf", summary: "Example funding confirmation for the fictional preview applicant." }] }
];
const initialApprovedApplications = demoApplications.filter((application) => application.status === "Approved").length;
let selectedDemoApplicationRef = "";
let selectedDemoDocumentIndex = -1;
const residenceNames = [
  "Vaal Student Hive",
  "18On Demeter",
  "4Anthenia Student Accomodation",
  "9@Wellies Student Accomodation",
  "Bovua@10Bellona",
  "Bovua@17Helious",
  "Bovua@2Bellona",
  "Bovua@36Aurora",
  "Bovua@ Borea Student Accomodation",
  "Bovua@16Fortuna",
  "Bovua@22Penelope",
  "Bovua@39Galatea",
  "Bovua@45Penelope",
  "Bovua Student Accomodation Bovua@21",
  "Koeneng Student Accomodation",
  "Lefari Student Accomodation",
  "Langelihle Student Accomodation",
  "Leep City Student Accomodation",
  "lima Student Accomodation",
  "Lora Student Acomodation",
  "Lufuno Student Accomodation",
  "MNM2 Student Accomodation",
  "1999 Student ACCOMODATION",
  "Queens",
  "Shakali Student Accomodation",
  "Bovua@18Bellona",
  "Bovua@19Hector",
  "Bovua@1Ganymade",
  "Bovua@26Anthenia",
  "Bovua@28Anthenia"
];
const demoNavigation = [
  ["Overview", "◫"],
  ["Applications", "▤"],
  ["Residences", "⌂"],
  ["Room Management", "▦"],
  ["Student Documents", "▧"],
  ["Reports", "▥"]
];

function renderDemoNavigation(className) {
  return `<nav class="${className}" aria-label="Preview navigation"><div class="sidebar-nav">${demoNavigation.map(([label, icon], index) => `
    <button class="nav-item${index === 0 ? " active" : ""}" type="button" data-view="${label}"><span class="nav-icon">${icon}</span>${label}</button>`).join("")}</div></nav>`;
}

function statusClass(status) {
  return status.toLowerCase().replace(/\s+/g, "-");
}

function escapeDemoHtml(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function renderDemoTable(rows) {
  if (!rows.length) return `<p class="empty-state">No sample applicants match your search.</p>`;
  return `<div class="table-scroll"><table>
    <thead><tr><th>ACTION</th><th>STUDENT</th><th>APPLICATION REF.</th><th>RESIDENCE</th><th>SUBMITTED</th><th>STATUS</th></tr></thead>
    <tbody>${rows.map((item) => `<tr>
      <td>${item.status === "Pending" || item.status === "Under review"
        ? `<button class="process-button" type="button" data-process-ref="${item.ref}" aria-label="Process application ${item.ref}">Process</button>`
        : `<button class="process-button" type="button" disabled>${item.status === "Approved" ? "Processed" : "Needs correction"}</button>`}</td>
      <td><button class="demo-applicant-name" type="button" data-open-demo-application="${escapeDemoHtml(item.ref)}">${escapeDemoHtml(item.name)}</button><small>${escapeDemoHtml(item.student)}</small></td>
      <td class="reference">${item.ref}</td><td>${item.residence}</td><td>${item.submitted}</td>
      <td><span class="status status-${statusClass(item.status)}"><span></span>${item.status}</span></td>
    </tr>`).join("")}</tbody>
  </table></div>`;
}

function getProcessableApplications() {
  return demoApplications.filter((application) => application.status === "Pending" || application.status === "Under review");
}

function updateProcessAllButton() {
  const button = document.querySelector("[data-process-all]");
  if (!button) return;

  const remaining = getProcessableApplications().length;
  button.textContent = remaining ? `Process all (${remaining})` : "All processed";
  button.disabled = remaining === 0;
}

function renderDemo() {
  app.innerHTML = `
    <div class="demo-layout">
      <aside class="sidebar">
        ${logo}
        <div class="demo-sidebar-label">WORKSPACE <span>PREVIEW</span></div>
        ${renderDemoNavigation("sidebar-nav")}
        <div class="sidebar-bottom"><a href="/login"><span class="nav-icon">↩</span>Exit preview</a><small>Vaal Student Hive<br>Staff Workspace</small></div>
      </aside>
      <main class="demo-main">
        <header class="demo-header">
          <div class="mobile-brand">${logo}</div>
          <div class="header-title"><span>STAFF WORKSPACE</span><h1 id="page-title">Overview</h1></div>
          <div class="header-actions"><button class="process-applications-button" type="button" data-process-all>Process all (${getProcessableApplications().length})</button>${renderThemeToggle()}<span class="demo-pill"><span></span> DEMO PREVIEW</span><span class="avatar">VH</span></div>
        </header>
        ${renderDemoNavigation("mobile-demo-nav")}
        <div class="preview-banner"><span class="preview-mark">i</span><p><strong>Preview mode</strong> — Process buttons simulate accepting fictional sample applications only. No live student records or management tools are connected.</p></div>
        <p id="demo-action-message" class="dashboard-notice notice-success" role="status" aria-live="polite" hidden></p>
        <section id="demo-content" aria-live="polite"></section>
        <footer class="demo-footer">Sample figures for demonstration only <span>•</span> No live data connection</footer>
      </main>
    </div>`;
  renderDemoOverview();
  bindThemeToggle();
  document.querySelectorAll(".nav-item").forEach((button) => button.addEventListener("click", () => {
    document.querySelectorAll(".nav-item").forEach((item) => item.classList.toggle("active", item.dataset.view === button.dataset.view));
    renderDemoSection(button.dataset.view);
  }));
  document.querySelector("[data-process-all]").addEventListener("click", () => {
    const processableApplications = getProcessableApplications();
    processableApplications.forEach((application) => {
      application.status = "Approved";
    });
    updateProcessAllButton();
    renderDemoSection(document.querySelector(".nav-item.active").dataset.view);
    showDemoActionMessage(processableApplications.length
      ? `Preview complete: ${processableApplications.length} sample application${processableApplications.length === 1 ? "" : "s"} processed. No live records were changed.`
      : "There are no sample applications waiting to be processed.");
  });
  document.querySelector("#demo-content").addEventListener("click", (event) => {
    const printButton = event.target.closest("[data-print-demo]");
    if (printButton) {
      window.print();
      return;
    }
    const backButton = event.target.closest("[data-back-demo-applications]");
    if (backButton) {
      selectedDemoApplicationRef = "";
      selectedDemoDocumentIndex = -1;
      renderDemoSection("Applications");
      return;
    }
    const documentButton = event.target.closest("[data-demo-document]");
    if (documentButton) {
      selectedDemoDocumentIndex = Number(documentButton.dataset.demoDocument);
      renderDemoSection("Applications");
      return;
    }
    const applicantButton = event.target.closest("[data-open-demo-application]");
    if (applicantButton) {
      selectedDemoApplicationRef = applicantButton.dataset.openDemoApplication;
      selectedDemoDocumentIndex = -1;
      document.querySelectorAll("[data-view]").forEach((item) => item.classList.toggle("active", item.dataset.view === "Applications"));
      renderDemoSection("Applications");
      return;
    }
    const button = event.target.closest("[data-process-ref]");
    if (!button) return;

    const application = demoApplications.find((item) => item.ref === button.dataset.processRef);
    if (!application || (application.status !== "Pending" && application.status !== "Under review")) return;

    application.status = "Approved";
    updateProcessAllButton();
    renderDemoSection(document.querySelector(".nav-item.active").dataset.view);
    showDemoActionMessage(`Preview complete: ${application.name}'s sample application was processed. No live records were changed.`);
  });
  document.querySelector("#demo-content").addEventListener("submit", (event) => {
    const form = event.target.closest("#demo-application-search");
    if (!form) return;
    event.preventDefault();
    demoApplicationQuery = String(new FormData(form).get("query") || "").trim();
    renderDemoSection("Applications");
    document.querySelector("#demo-application-query").focus();
  });
}

function showDemoActionMessage(message) {
  demoActionMessage = message;
  const notice = document.querySelector("#demo-action-message");
  if (!notice) return;
  notice.textContent = demoActionMessage;
  notice.hidden = false;
}

function renderDemoOverview() {
  const processedCount = demoApplications.filter((application) => application.status === "Approved").length - initialApprovedApplications;
  const approvedCount = 76 + processedCount;
  const stats = [
    ["Total applications", "128", "+ 12 this month", "▤", "stat-red"],
    ["Pending review", String(24 - processedCount), "Needs attention", "◷", "stat-amber"],
    ["Approved", String(approvedCount), `${Math.round((approvedCount / 128) * 100)}% of applications`, "✓", "stat-green"],
    ["Residences", String(residenceNames.length), "Names supplied for preview", "⌂", "stat-blue"]
  ];
  document.querySelector("#demo-content").innerHTML = `
    <div class="stats-grid">${stats.map(([label, value, note, icon, color]) => `
      <article class="stat-card"><div class="stat-card-top"><span>${label}</span><span class="stat-icon ${color}">${icon}</span></div><strong>${value}</strong><small>${note}</small></article>`).join("")}</div>
    <section class="panel applications-panel">
      <div class="panel-heading"><div><h2>Recent applications</h2><p>A snapshot of sample application activity</p></div><span class="sample-tag">SAMPLE DATA</span></div>
      ${renderDemoTable(demoApplications)}
    </section>
    <div class="demo-footnote"><span aria-hidden="true">✦</span><p><strong>Exploring the preview?</strong> Navigation and Process actions are for demonstration only. They do not change real records or contact students.</p></div>`;
}

function renderDemoSection(section) {
  document.querySelector("#page-title").textContent = section;
  const content = document.querySelector("#demo-content");
  if (section === "Overview") {
    renderDemoOverview();
    return;
  }
  if (section === "Applications") {
    const selectedApplication = demoApplications.find((application) => application.ref === selectedDemoApplicationRef);
    if (selectedApplication) {
      const selectedDocument = selectedApplication.documents[selectedDemoDocumentIndex];
      content.innerHTML = `<section class="panel info-panel demo-applicant-details">
        <div class="panel-heading"><div><h2>${escapeDemoHtml(selectedApplication.name)}</h2><p>Fictional applicant details · ${escapeDemoHtml(selectedApplication.ref)}</p></div><span class="sample-tag">SAMPLE DATA</span></div>
        <dl class="application-details">
          <div><dt>Applicant</dt><dd>${escapeDemoHtml(selectedApplication.name)}</dd></div>
          <div><dt>Student number</dt><dd>${escapeDemoHtml(selectedApplication.student)}</dd></div>
          <div><dt>Application reference</dt><dd>${escapeDemoHtml(selectedApplication.ref)}</dd></div>
          <div><dt>Residence</dt><dd>${escapeDemoHtml(selectedApplication.residence)}</dd></div>
          <div><dt>Submitted</dt><dd>${escapeDemoHtml(selectedApplication.submitted)}</dd></div>
          <div><dt>Status</dt><dd>${escapeDemoHtml(selectedApplication.status)}</dd></div>
        </dl>
        <div class="demo-print-actions"><button class="process-button" type="button" data-print-demo>Print applicant details</button><button class="button button-secondary demo-back-button" type="button" data-back-demo-applications>Back to sample applications</button></div>
        <div class="document-list"><h3>Sample document previews</h3><p class="demo-document-note">These are illustrative placeholders, not uploaded files or real student documents.</p>
          <div class="preview-list demo-document-list">${selectedApplication.documents.map((document, index) => `<div class="preview-list-item"><strong>${escapeDemoHtml(document.name)}</strong><span><button class="document-button" type="button" data-demo-document="${index}">${selectedDemoDocumentIndex === index ? "Viewing sample" : "View sample"}</button></span></div>`).join("")}</div>
          ${selectedDocument ? `<article class="demo-document-preview"><div class="demo-document-controls"><span class="sample-tag">FICTIONAL DOCUMENT PREVIEW</span><button class="process-button" type="button" data-print-demo>Print document</button></div><h4>${escapeDemoHtml(selectedDocument.name)}</h4><p>${escapeDemoHtml(selectedDocument.summary)}</p><p class="demo-document-watermark">SAMPLE ONLY · NOT AN UPLOADED DOCUMENT</p></article>` : ""}
        </div>
      </section>`;
      return;
    }
    const query = demoApplicationQuery.toLocaleLowerCase();
    const matchingApplications = demoApplications.filter((application) => application.name.toLocaleLowerCase().includes(query));
    content.innerHTML = `<section class="panel applications-panel"><div class="panel-heading"><div><h2>Sample applications</h2><p>Fictional records for preview only</p></div><span class="sample-tag">SAMPLE DATA</span></div>
      <form id="demo-application-search" class="demo-application-search">
        <label for="demo-application-query">Search applicant name</label>
        <div><input id="demo-application-query" name="query" type="search" value="${escapeDemoHtml(demoApplicationQuery)}" placeholder="Enter an applicant name"><button class="process-button" type="submit">Search</button></div>
      </form>
      ${renderDemoTable(matchingApplications)}</section>`;
    return;
  }
  const sections = {
    "Residences": ["Residences", "Residence names supplied for this preview. Capacity and availability are not connected to a database.", residenceNames.map((name) => [name, "Capacity not configured in preview"])],
    "Room Management": ["Room management", "Room capacity and allocations are not configured in this preview.", residenceNames.map((name) => [name, "Room information unavailable"])],
    "Student Documents": ["Student documents", "Private student documents are never loaded in the preview.", [["Document access", "Unavailable in read-only demo"], ["Storage", "Not connected"], ["Student records", "Not accessed"]]],
    "Reports": ["Reports", "Illustrative summary figures only; no report is connected to live records.", [["Applications", "128 sample applications"], ["Decisions", "76 approved · 14 rejected"], ["Room occupancy", "Not configured"]]]
  };
  const [title, description, items] = sections[section];
  content.innerHTML = `<section class="panel info-panel"><div class="panel-heading"><div><h2>${title}</h2><p>${description}</p></div><span class="sample-tag">SAMPLE DATA</span></div><div class="preview-list">${items.map(([name, detail]) => `<div class="preview-list-item"><strong>${name}</strong><span>${detail}</span></div>`).join("")}</div></section>`;
}

if (isDemo) {
  renderDemo();
} else if (path === "/login") {
  const managementScript = document.createElement("script");
  managementScript.src = "/management.js";
  const supabaseScript = document.createElement("script");
  supabaseScript.src = "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.js";
  supabaseScript.onload = () => document.body.append(managementScript);
  supabaseScript.onerror = () => document.body.append(managementScript);
  document.body.append(supabaseScript);
}
