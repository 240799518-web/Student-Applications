(() => {
  if (window.location.pathname.replace(/\/+$/, "") === "/demo" || window.location.hash === "#demo") return;

  const app = document.querySelector("#app");
  const allowedStatuses = ["under_review", "approved", "rejected"];
  const pageSize = 500;
  let supabase;
  let supabaseConfig;
  let authSubscription;
  let session;
  let applications = [];
  let residences = [];
  let dataErrors = { applications: null, residences: null };
  let activeView = "Overview";
  let searchQuery = "";
  let statusFilter = "";
  let selectedApplicationId = "";
  let notice = null;
  let initializing = false;
  let currentTheme = document.documentElement.dataset.theme || "light";

  const navigation = [
    ["Overview", "◫"],
    ["Applications", "▤"],
    ["Residences", "⌂"],
    ["Room Management", "▦"],
    ["Student Documents", "▧"],
    ["Reports", "▥"]
  ];

  const escapeHtml = (value) => String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");

  function hasSupabaseAuth() {
    return Boolean(supabase && supabase.auth
      && typeof supabase.auth.signInWithPassword === "function"
      && typeof supabase.auth.resetPasswordForEmail === "function");
  }

  function hasSupabaseDataClient() {
    return Boolean(supabase && typeof supabase.from === "function"
      && typeof supabase.rpc === "function" && supabase.storage);
  }

  function friendlyAuthError(error, action) {
    const code = String(error && error.code || "").toLowerCase();
    const message = String(error && error.message || "").toLowerCase();
    if (code === "email_not_confirmed" || message.includes("email not confirmed")) {
      return "This staff account's email address has not been confirmed. Ask an administrator to check the account.";
    }
    if (["invalid_credentials", "invalid_login_credentials"].includes(code)
      || message.includes("invalid login credentials") || message.includes("invalid email or password")) {
      return "The email address or password is incorrect.";
    }
    if (["session_not_found", "refresh_token_not_found", "bad_jwt", "session_expired"].includes(code)
      || error && error.status === 401
      || message.includes("session expired") || message.includes("token is expired")) {
      return "Your login is no longer valid. Log in to continue.";
    }
    if (error && error.name === "AuthRetryableFetchError"
      || message.includes("failed to fetch") || message.includes("network") || message.includes("load failed")) {
      return "We couldn't connect to the authentication service. Check your internet connection and try again.";
    }
    if (action === "signout") {
      return "We couldn't end your session. Check your internet connection and try again.";
    }
    if (error && (error.status === 429 || code.includes("rate_limit"))) {
      return "Too many attempts were made. Wait a few minutes, then try again.";
    }
    if (action === "recovery") {
      return "We couldn't request a password reset right now. Check the email address and try again.";
    }
    if (action === "password") {
      return "We couldn't update your password. The reset link may have expired; request a new one and try again.";
    }
    return "We couldn't complete sign-in. Check your details and try again.";
  }

  const formatDate = (value) => {
    if (!value) return "Not provided";
    const date = new Date(`${value}`.length === 10 ? `${value}T00:00:00` : value);
    return Number.isNaN(date.getTime()) ? "Not provided" : new Intl.DateTimeFormat(undefined, { dateStyle: "medium" }).format(date);
  };

  const statusLabel = (status) => ({
    submitted: "Submitted",
    under_review: "Under review",
    approved: "Approved",
    rejected: "Rejected"
  }[status] || status || "Unknown");

  const statusClass = (status) => String(status || "unknown").replace(/[^a-z0-9_-]/gi, "-").toLowerCase();

  const brand = `
    <a class="brand" href="/" aria-label="Student Heights management workspace">
      <span class="brand-logo"><img src="/images/Logo.jpg" alt="Student Heights accommodation logo"></span>
      <span class="brand-copy"><strong>STUDENT HEIGHTS</strong><span>MANAGEMENT WORKSPACE</span></span>
    </a>`;

  function renderManagementThemeToggle() {
    const isDark = currentTheme === "dark";
    return `<button class="theme-toggle" type="button" aria-label="Switch to ${isDark ? "bright" : "dark"} mode" aria-pressed="${isDark}">
      <span class="theme-icon" aria-hidden="true">${isDark ? "☀" : "☾"}</span><span>${isDark ? "Bright mode" : "Dark mode"}</span>
    </button>`;
  }

  function bindManagementThemeToggle() {
    document.querySelectorAll(".theme-toggle").forEach((button) => button.addEventListener("click", () => {
      currentTheme = currentTheme === "dark" ? "light" : "dark";
      document.documentElement.dataset.theme = currentTheme;
      try {
        window.localStorage.setItem("vsh-theme", currentTheme);
      } catch (error) {
        console.warn("Unable to save the display theme.", error);
      }
      document.querySelectorAll(".theme-toggle").forEach((toggle) => {
        const isDark = currentTheme === "dark";
        toggle.setAttribute("aria-label", `Switch to ${isDark ? "bright" : "dark"} mode`);
        toggle.setAttribute("aria-pressed", String(isDark));
        toggle.innerHTML = `<span class="theme-icon" aria-hidden="true">${isDark ? "☀" : "☾"}</span><span>${isDark ? "Bright mode" : "Dark mode"}</span>`;
      });
    }));
  }

  function renderLoading(message) {
    app.innerHTML = `<main class="management-loading" role="status"><span class="loading-spinner" aria-hidden="true"></span><p>${escapeHtml(message)}</p></main>`;
  }

  function showLogin(message = "") {
    session = null;
    app.innerHTML = `
      <main class="login-layout">
        <section class="welcome-panel" aria-labelledby="welcome-title">
          <div class="welcome-top">${brand}${renderManagementThemeToggle()}</div>
          <div class="welcome-content">
            <span class="eyebrow"><span class="eyebrow-dot"></span> RESIDENCE MANAGEMENT</span>
            <h1 id="welcome-title">A clearer way to manage <em>residence applications.</em></h1>
            <p>Review applications, documents, and room availability in one protected workspace for authorised staff.</p>
            <div class="security-note"><span class="shield-icon" aria-hidden="true">✓</span><span><strong>Authorised management access only</strong><small>Private workspace for Student Heights staff</small></span></div>
          </div>
          <div class="welcome-footer">A welcoming place to live, learn and grow.</div>
          <div class="welcome-decoration decoration-one"></div><div class="welcome-decoration decoration-two"></div>
        </section>
        <section class="form-panel" aria-labelledby="login-title">
          <div class="form-panel-inner">
            <div class="mobile-brand-row"><div class="mobile-brand">${brand}</div>${renderManagementThemeToggle()}</div>
            <span class="section-label">WELCOME BACK, STAFF</span>
            <h2 id="login-title">Welcome back</h2>
            <p class="form-intro">Good to see you. Sign in with your authorised staff account to continue.</p>
            <form id="management-login" novalidate>
              <label for="staff-email">Staff email address</label>
              <input id="staff-email" name="email" type="email" autocomplete="username" required>
              <label for="staff-password">Password</label>
              <div class="password-wrap"><input id="staff-password" name="password" type="password" autocomplete="current-password" required>
                <button class="show-password" type="button" aria-label="Show password" aria-pressed="false">Show</button></div>
              <div class="form-utilities"><span></span>              <button class="text-button" type="button" id="forgot-password"${hasSupabaseAuth() ? "" : " disabled"}>Forgot your password?</button></div>
              <p class="form-message" id="login-message" role="alert" aria-live="polite">${escapeHtml(message)}</p>
              <button class="button button-primary sign-in" type="submit"${hasSupabaseAuth() ? "" : " disabled"}>Sign in <span aria-hidden="true">→</span></button>
            </form>
            <button class="text-button connection-retry" type="button" data-retry-connection>Retry connection</button>
            <a class="button button-secondary preview-access-button" href="/demo">Preview the management workspace <span aria-hidden="true">→</span></a>
            <p class="demo-caption">Explore sample applications and document previews without a Supabase connection.</p>
            <div class="provision-note"><span class="info-icon" aria-hidden="true">i</span><p>Management accounts are provisioned by an administrator. There is no public account registration.</p></div>
            <footer class="form-footer">© ${new Date().getFullYear()} Student Heights <span>•</span> Staff Workspace</footer>
          </div>
        </section>
      </main>`;
    bindManagementThemeToggle();

    document.querySelector("#management-login").addEventListener("submit", async (event) => {
      event.preventDefault();
      const email = document.querySelector("#staff-email");
      const password = document.querySelector("#staff-password");
      const messageElement = document.querySelector("#login-message");
      if (!hasSupabaseAuth()) {
        messageElement.textContent = "Sign-in is temporarily unavailable because the authentication service did not initialize. Reload the page or contact the site administrator.";
        return;
      }
      if (!email.value.trim() || !email.validity.valid) {
        messageElement.textContent = "Enter a valid staff email address.";
        email.focus();
        return;
      }
      if (!password.value) {
        messageElement.textContent = "Enter your password.";
        password.focus();
        return;
      }

      const button = event.currentTarget.querySelector('button[type="submit"]');
      button.disabled = true;
      messageElement.textContent = "Signing in…";
      try {
        const { data, error } = await supabase.auth.signInWithPassword({ email: email.value.trim(), password: password.value });
        if (error) {
          messageElement.textContent = friendlyAuthError(error, "signin");
          return;
        }
        const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
        if (sessionError || !sessionData.session || !data.user || sessionData.session.user.id !== data.user.id) {
          messageElement.textContent = sessionError
            ? friendlyAuthError(sessionError, "signin")
            : "We couldn't verify your sign-in session. Please try again.";
          return;
        }
        if (!isManagementUser(sessionData.session.user)) {
          const { error: signOutError } = await supabase.auth.signOut();
          messageElement.textContent = signOutError
            ? "This account is not authorised for management, and sign-out could not be completed. Contact an administrator."
            : "This account is not authorised for management. Ask an administrator to provision access.";
          return;
        }
        session = sessionData.session;
        await enterDashboard("Welcome back! You're signed in and your workspace is ready.");
      } catch (error) {
        messageElement.textContent = friendlyAuthError(error, "signin");
      } finally {
        button.disabled = false;
      }
    });

    const passwordInput = document.querySelector("#staff-password");
    document.querySelector(".show-password").addEventListener("click", (event) => {
      const reveal = passwordInput.type === "password";
      passwordInput.type = reveal ? "text" : "password";
      event.currentTarget.textContent = reveal ? "Hide" : "Show";
      event.currentTarget.setAttribute("aria-label", reveal ? "Hide password" : "Show password");
      event.currentTarget.setAttribute("aria-pressed", String(reveal));
    });

    document.querySelector("#forgot-password").addEventListener("click", async (event) => {
      const email = document.querySelector("#staff-email");
      const messageElement = document.querySelector("#login-message");
      if (!hasSupabaseAuth()) {
        messageElement.textContent = "Password recovery is temporarily unavailable because the authentication service did not initialize. Reload the page or contact the site administrator.";
        return;
      }
      if (!email.value.trim() || !email.validity.valid) {
        messageElement.textContent = "Enter your staff email address first.";
        email.focus();
        return;
      }
      const button = event.currentTarget;
      button.disabled = true;
      messageElement.textContent = "Requesting password recovery…";
      try {
        const { error } = await supabase.auth.resetPasswordForEmail(email.value.trim(), { redirectTo: window.location.origin });
        messageElement.textContent = error
          ? friendlyAuthError(error, "recovery")
          : "If an account exists for that address, a password recovery email has been sent.";
      } catch (error) {
        messageElement.textContent = friendlyAuthError(error, "recovery");
      } finally {
        button.disabled = false;
      }
    });
  }

  function showPasswordRecovery(recoverySession) {
    session = recoverySession;
    app.innerHTML = `
      <main class="login-layout">
        <section class="form-panel recovery-panel" aria-labelledby="recovery-title">
          <div class="form-panel-inner">
            <span class="section-label">MANAGEMENT LOGIN</span>
            <h2 id="recovery-title">Choose a new password</h2>
            <p class="form-intro">Enter and confirm your new staff account password.</p>
            <form id="password-recovery-form" novalidate>
              <label for="new-password">New password</label>
              <input id="new-password" name="password" type="password" autocomplete="new-password" required>
              <label for="confirm-password">Confirm new password</label>
              <input id="confirm-password" name="confirm-password" type="password" autocomplete="new-password" required>
              <p class="form-message" id="recovery-message" role="alert" aria-live="polite"></p>
              <button class="button button-primary sign-in" type="submit">Update password</button>
            </form>
          </div>
        </section>
      </main>`;

    document.querySelector("#password-recovery-form").addEventListener("submit", async (event) => {
      event.preventDefault();
      const password = document.querySelector("#new-password");
      const confirmation = document.querySelector("#confirm-password");
      const messageElement = document.querySelector("#recovery-message");
      if (!password.value) {
        messageElement.textContent = "Enter a new password.";
        password.focus();
        return;
      }
      if (password.value !== confirmation.value) {
        messageElement.textContent = "The passwords do not match.";
        confirmation.focus();
        return;
      }

      const button = event.currentTarget.querySelector('button[type="submit"]');
      button.disabled = true;
      messageElement.textContent = "Updating password…";
      try {
        const { error } = await supabase.auth.updateUser({ password: password.value });
        if (error) {
          messageElement.textContent = friendlyAuthError(error, "password");
          return;
        }
        await enterDashboard();
      } catch (error) {
        messageElement.textContent = friendlyAuthError(error, "password");
      } finally {
        button.disabled = false;
      }
    });
  }

  function isManagementUser(user) {
    return Boolean(user && user.app_metadata && user.app_metadata.role === "management");
  }

  function renderNavigation(className) {
    return `<nav class="${className}" aria-label="Management navigation"><div class="sidebar-nav">${navigation.map(([label, icon]) => `
      <button class="nav-item${activeView === label ? " active" : ""}" type="button" data-view="${escapeHtml(label)}"><span class="nav-icon" aria-hidden="true">${icon}</span>${escapeHtml(label)}</button>`).join("")}</div></nav>`;
  }

  function renderDashboardShell() {
    const email = session && session.user ? session.user.email : "";
    app.innerHTML = `
      <div class="demo-layout management-layout">
        <aside class="sidebar">${brand}<div class="demo-sidebar-label">WORKSPACE <span>LIVE</span></div>${renderNavigation("sidebar-nav")}
          <div class="sidebar-bottom"><button class="sign-out-link" type="button" data-sign-out><span class="nav-icon" aria-hidden="true">↩</span>Sign out</button><small>Student Heights<br>Management Workspace</small></div>
        </aside>
        <main class="demo-main">
          <header class="demo-header">
            <div class="mobile-brand">${brand}</div>
            <div class="header-title"><span>MANAGEMENT WORKSPACE</span><h1 id="page-title">${escapeHtml(activeView)}</h1></div>
            <div class="header-actions"><span class="management-user">${escapeHtml(email)}</span>${renderManagementThemeToggle()}<button class="button button-secondary compact-sign-out" type="button" data-sign-out>Sign out</button></div>
          </header>
          ${renderNavigation("mobile-demo-nav")}
          <div id="dashboard-notice" aria-live="polite"></div>
          <section id="management-content" aria-live="polite"></section>
          <footer class="demo-footer">Live data from the authorised Student Heights Supabase project</footer>
        </main>
      </div>`;

    bindManagementThemeToggle();
    const content = document.querySelector("#management-content");
    content.addEventListener("submit", saveApplicationStatus);
    content.addEventListener("click", (event) => {
      const button = event.target.closest("[data-retry-load]");
      if (button) enterDashboard();
    });
    document.querySelectorAll("[data-view]").forEach((button) => button.addEventListener("click", () => {
      activeView = button.dataset.view;
      selectedApplicationId = "";
      document.querySelectorAll("[data-view]").forEach((item) => item.classList.toggle("active", item.dataset.view === activeView));
      renderCurrentView();
    }));
    document.querySelectorAll("[data-sign-out]").forEach((button) => button.addEventListener("click", signOut));
    renderCurrentView();
  }

  function setNotice(message, kind = "info") {
    notice = message ? { message, kind } : null;
    const target = document.querySelector("#dashboard-notice");
    if (target) {
      target.innerHTML = notice
        ? `<p class="dashboard-notice notice-${kind}" role="${kind === "error" ? "alert" : "status"}">${escapeHtml(message)}</p>`
        : "";
    }
  }

  function applicationCount(status) {
    return applications.filter((application) => application.status === status).length;
  }

  function renderStats() {
    const stats = [
      ["Submitted", applicationCount("submitted"), "Awaiting review", "▤", "stat-red"],
      ["Under review", applicationCount("under_review"), "Currently in review", "◷", "stat-amber"],
      ["Approved", applicationCount("approved"), "Approved applications", "✓", "stat-green"],
      ["Rejected", applicationCount("rejected"), "Rejected applications", "×", "stat-blue"]
    ];
    return `<div class="stats-grid">${stats.map(([label, count, noteText, icon, color]) => `
      <article class="stat-card"><div class="stat-card-top"><span>${label}</span><span class="stat-icon ${color}" aria-hidden="true">${icon}</span></div><strong>${count}</strong><small>${noteText}</small></article>`).join("")}</div>`;
  }

  function applicationRow(application) {
    const name = [application.first_name, application.surname].filter(Boolean).join(" ") || "Name not provided";
    const submitted = application.submitted_at || application.created_at;
    return `<tr>
      <td><button class="process-button" type="button" data-open-application="${escapeHtml(application.id)}">Details</button></td>
      <td><strong>${escapeHtml(name)}</strong><small>${escapeHtml(application.student_number || "Student number not provided")}</small></td>
      <td class="reference">${escapeHtml(application.application_reference)}</td>
      <td>${escapeHtml(application.residence_name || "Not provided")}</td>
      <td>${escapeHtml(formatDate(submitted))}</td>
      <td><span class="status status-${statusClass(application.status)}"><span></span>${escapeHtml(statusLabel(application.status))}</span></td>
    </tr>`;
  }

  function renderApplicationsTable(rows) {
    if (!rows.length) return `<p class="empty-state">No applications match these filters.</p>`;
    return `<div class="table-scroll"><table>
      <thead><tr><th>DETAILS</th><th>STUDENT</th><th>APPLICATION REF.</th><th>RESIDENCE</th><th>SUBMITTED</th><th>STATUS</th></tr></thead>
      <tbody>${rows.map(applicationRow).join("")}</tbody>
    </table></div>`;
  }

  function renderApplicationList(recentOnly = false) {
    const query = searchQuery.trim().toLocaleLowerCase();
    let rows = applications.filter((application) => {
      const fields = [
        [application.first_name, application.surname].filter(Boolean).join(" "),
        application.first_name,
        application.surname,
        application.student_number,
        application.application_reference,
        application.residence_name
      ];
      return (!query || fields.some((value) => String(value || "").toLocaleLowerCase().includes(query)))
        && (!statusFilter || application.status === statusFilter);
    });
    if (recentOnly) rows = rows.slice(0, 12);
    return `<section class="panel applications-panel">
      <div class="panel-heading"><div><h2>${recentOnly ? "Recent applications" : "Applications"}</h2><p>${recentOnly ? "Most recently submitted live applications" : `${rows.length} matching application${rows.length === 1 ? "" : "s"}`}</p></div></div>
      ${recentOnly ? "" : `<form id="application-filters" class="application-filters">
        <label for="application-search">Search student name, student number, reference, or residence</label>
        <input id="application-search" name="query" type="search" value="${escapeHtml(searchQuery)}" placeholder="Search applications">
        <label for="application-status">Status</label><select id="application-status" name="status">
          <option value="">All statuses</option>${["submitted", "under_review", "approved", "rejected"].map((status) => `<option value="${status}"${statusFilter === status ? " selected" : ""}>${statusLabel(status)}</option>`).join("")}
        </select>
        <button class="process-button" type="submit">Search</button>
      </form>`}
      ${renderApplicationsTable(rows)}
    </section>`;
  }

  function renderOverview() {
    const applicationContent = dataErrors.applications
      ? renderDataError("applications", dataErrors.applications)
      : `${renderStats()}${renderApplicationList(true)}<div class="dashboard-footnote"><span aria-hidden="true">✓</span><p>Application records and counts are loaded from Supabase and subject to management row-level security.</p></div>`;
    return `${applicationContent}${dataErrors.residences ? renderDataError("residences", dataErrors.residences) : ""}`;
  }

  function renderDataError(source, error) {
    const label = source === "applications" ? "applications" : "residences";
    return `<section class="panel info-panel"><div class="panel-heading"><div><h2>Unable to load ${label}</h2><p>${escapeHtml(error.message || "Unexpected data loading error.")}</p></div></div><button class="process-button" type="button" data-retry-load>Retry</button></section>`;
  }

  function documentLabel(field) {
    return ({
      proof_of_registration_path: "Proof of registration",
      proof_of_funding_path: "Proof of funding",
      identity_document_path: "Identity document"
    }[field]);
  }

  function renderApplicationDetails() {
    const application = applications.find((record) => record.id === selectedApplicationId);
    if (!application) {
      selectedApplicationId = "";
      return renderApplicationList();
    }
    const documents = ["proof_of_registration_path", "proof_of_funding_path", "identity_document_path"];
    const statusControls = ["submitted", "under_review"].includes(application.status)
      ? `<form class="status-change-form" data-status-form="${escapeHtml(application.id)}">
          <label for="new-status">Change status</label>
          <select id="new-status" name="status" required>${allowedStatuses.map((status) => `<option value="${status}"${application.status === status ? " selected" : ""}>${statusLabel(status)}</option>`).join("")}</select>
          <button class="process-button" type="submit">Save status</button>
        </form>`
      : `<p class="detail-note">This application is ${escapeHtml(statusLabel(application.status).toLowerCase())}. Its status cannot be changed from this dashboard.</p>`;
    return `<section class="panel info-panel">
      <div class="panel-heading"><div><h2>Application ${escapeHtml(application.application_reference)}</h2><p>Student details and submitted application information</p></div><button class="process-button" type="button" data-back-applications>Back to applications</button></div>
      <dl class="application-details">
        <div><dt>Student name</dt><dd>${escapeHtml([application.first_name, application.surname].filter(Boolean).join(" ") || "Not provided")}</dd></div>
        <div><dt>Student number</dt><dd>${escapeHtml(application.student_number || "Not provided")}</dd></div>
        <div><dt>Email</dt><dd>${escapeHtml(application.email || "Not provided")}</dd></div>
        <div><dt>Phone</dt><dd>${escapeHtml(application.phone || "Not provided")}</dd></div>
        <div><dt>Application reference</dt><dd>${escapeHtml(application.application_reference)}</dd></div>
        <div><dt>Requested residence</dt><dd>${escapeHtml(application.residence_name || "Not provided")}</dd></div>
        <div><dt>Move-in date</dt><dd>${escapeHtml(formatDate(application.move_in_date))}</dd></div>
        <div><dt>Room type</dt><dd>${escapeHtml(application.room_type || "Not provided")}</dd></div>
        <div><dt>Submission date</dt><dd>${escapeHtml(formatDate(application.submitted_at || application.created_at))}</dd></div>
        <div><dt>Status</dt><dd><span class="status status-${statusClass(application.status)}"><span></span>${escapeHtml(statusLabel(application.status))}</span></dd></div>
      </dl>
      ${statusControls}
      <div class="document-list"><h3>Application documents</h3><div class="preview-list">${documents.map((field) => application[field]
        ? `<div class="preview-list-item"><strong>${documentLabel(field)}</strong><span><button class="document-button" type="button" data-document-field="${field}" data-application-id="${escapeHtml(application.id)}">Open securely</button></span></div>`
        : `<div class="preview-list-item"><strong>${documentLabel(field)}</strong><span>Not available</span></div>`).join("")}</div></div>
    </section>`;
  }

  function renderResidences() {
    if (dataErrors.residences) return renderDataError("residences", dataErrors.residences);
    if (!residences.length) return `<section class="panel info-panel"><div class="panel-heading"><div><h2>Residences</h2><p>No residences are currently available to display.</p></div></div></section>`;
    return `<section class="panel info-panel"><div class="panel-heading"><div><h2>Residences</h2><p>Current residence names, addresses, and available room counts</p></div></div>
      <div class="preview-list">${residences.map((residence) => `<div class="preview-list-item">
        <strong>${escapeHtml(residence.name)}</strong><span>${escapeHtml(residence.address || "Address not provided")} · ${residence.available_rooms == null ? "Availability not provided" : `${escapeHtml(residence.available_rooms)} rooms available`}</span>
      </div>`).join("")}</div></section>`;
  }

  function renderReports() {
    const applicationSummary = dataErrors.applications
      ? `<div class="preview-list-item"><strong>Applications</strong><span>Unable to load: ${escapeHtml(dataErrors.applications.message || "unexpected error")}</span></div>`
      : ["submitted", "under_review", "approved", "rejected"].map((status) => `<div class="preview-list-item"><strong>${statusLabel(status)}</strong><span>${applicationCount(status)} applications</span></div>`).join("");
    const residenceSummary = dataErrors.residences
      ? `<div class="preview-list-item"><strong>Residences</strong><span>Unable to load: ${escapeHtml(dataErrors.residences.message || "unexpected error")}</span></div>`
      : `<div class="preview-list-item"><strong>Residences</strong><span>${residences.length} records</span></div>`;
    return `<section class="panel info-panel"><div class="panel-heading"><div><h2>Application reports</h2><p>Live counts based on records visible to this management account</p></div></div>
      <div class="preview-list">${applicationSummary}${residenceSummary}</div>${dataErrors.applications || dataErrors.residences ? '<button class="process-button" type="button" data-retry-load>Retry</button>' : ""}</section>`;
  }

  function renderCurrentView() {
    if (!document.querySelector("#management-content")) return;
    document.querySelector("#page-title").textContent = activeView;
    const content = document.querySelector("#management-content");
    if (activeView === "Overview") content.innerHTML = renderOverview();
    else if (activeView === "Applications") content.innerHTML = dataErrors.applications
      ? renderDataError("applications", dataErrors.applications)
      : selectedApplicationId ? renderApplicationDetails() : renderApplicationList();
    else if (activeView === "Residences" || activeView === "Room Management") content.innerHTML = renderResidences();
    else if (activeView === "Student Documents") {
      content.innerHTML = dataErrors.applications
        ? renderDataError("applications", dataErrors.applications)
        : `<section class="panel info-panel"><div class="panel-heading"><div><h2>Student documents</h2><p>Open documents from their application details using authenticated private storage access.</p></div></div>${renderApplicationList()}</section>`;
    } else if (activeView === "Reports") content.innerHTML = renderReports();

    const filters = document.querySelector("#application-filters");
    if (filters) filters.addEventListener("submit", (event) => {
      event.preventDefault();
      const formData = new FormData(filters);
      searchQuery = String(formData.get("query") || "");
      statusFilter = String(formData.get("status") || "");
      renderCurrentView();
    });

    content.querySelectorAll("[data-open-application]").forEach((button) => button.addEventListener("click", () => {
      selectedApplicationId = button.dataset.openApplication;
      activeView = "Applications";
      document.querySelectorAll("[data-view]").forEach((item) => item.classList.toggle("active", item.dataset.view === activeView));
      renderCurrentView();
    }));
    const backButton = content.querySelector("[data-back-applications]");
    if (backButton) backButton.addEventListener("click", () => {
      selectedApplicationId = "";
      renderCurrentView();
    });
    content.querySelectorAll("[data-document-field]").forEach((button) => button.addEventListener("click", openDocument));
    if (notice) setNotice(notice.message, notice.kind);
  }

  async function loadApplications() {
    const records = [];
    for (let offset = 0; ; offset += pageSize) {
      const { data, error } = await supabase.from("applications")
        .select("id,user_id,first_name,surname,student_number,email,phone,residence_name,move_in_date,room_type,created_at,application_reference,status,submitted_at,proof_of_registration_path,proof_of_funding_path,identity_document_path")
        .order("created_at", { ascending: false })
        .range(offset, offset + pageSize - 1);
      if (error) throw error;
      records.push(...data);
      if (data.length < pageSize) break;
    }
    applications = records;
  }

  async function loadResidences() {
    const { data, error } = await supabase.from("residences")
      .select("id,name,address,available_rooms,created_at")
      .order("name", { ascending: true });
    if (error) throw error;
    residences = data;
  }

  async function reloadData() {
    const results = await Promise.allSettled([loadApplications(), loadResidences()]);
    const getError = (result) => {
      if (result.status === "fulfilled") return null;
      return result.reason && typeof result.reason.message === "string"
        ? result.reason
        : new Error(String(result.reason || "Unexpected data loading error."));
    };
    dataErrors = {
      applications: getError(results[0]),
      residences: getError(results[1])
    };
  }

  async function enterDashboard(welcomeMessage = "") {
    if (!session || !isManagementUser(session.user)) {
      showLogin("This account is not authorised for management.");
      return;
    }
    if (!hasSupabaseDataClient()) {
      showConnectionUnavailable("Live database data is temporarily unavailable. Log in again after reconnecting.");
      return;
    }
    renderDashboardShell();
    document.querySelector("#management-content").innerHTML = `<p class="loading-inline" role="status">Loading live applications and residences…</p>`;
    await reloadData();
    const failures = Object.entries(dataErrors)
      .filter(([, error]) => error)
      .map(([source, error]) => `${source}: ${error.message || "unexpected error"}`);
    const noticeMessage = failures.length
      ? [welcomeMessage, `Some dashboard data could not be loaded: ${failures.join("; ")}`].filter(Boolean).join(" ")
      : welcomeMessage;
    setNotice(noticeMessage, failures.length ? "error" : "success");
    renderCurrentView();
  }

  async function saveApplicationStatus(event) {
    const form = event.target.closest("[data-status-form]");
    if (!form) return;
    event.preventDefault();
    const applicationId = form.dataset.statusForm;
    const selectedStatus = String(new FormData(form).get("status") || "");
    if (!allowedStatuses.includes(selectedStatus)) {
      setNotice("Choose a supported application status.", "error");
      return;
    }
    const button = form.querySelector('button[type="submit"]');
    button.disabled = true;
    setNotice("Saving application status…");
    try {
      const { error } = await supabase.rpc("management_set_application_status", {
        p_application_id: applicationId,
        p_status: selectedStatus
      });
      if (error) {
        setNotice(`Application status was not changed: ${error.message}`, "error");
        return;
      }
      setNotice("Application status updated successfully.", "success");
      try {
        await reloadData();
        renderCurrentView();
      } catch (error) {
        setNotice(`Status update succeeded, but refreshing the dashboard failed: ${error.message}`, "error");
      }
    } catch (error) {
      setNotice(`Application status was not changed: ${error.message || "Network request failed."}`, "error");
    } finally {
      button.disabled = false;
    }
  }

  async function openDocument(event) {
    const button = event.currentTarget;
    const application = applications.find((record) => record.id === button.dataset.applicationId);
    const field = button.dataset.documentField;
    const objectPath = application && application[field];
    if (!objectPath || !["proof_of_registration_path", "proof_of_funding_path", "identity_document_path"].includes(field)) {
      setNotice("This application document is unavailable.", "error");
      return;
    }
    const documentWindow = window.open("about:blank", "_blank");
    if (documentWindow) documentWindow.opener = null;
    button.disabled = true;
    setNotice(`Opening ${documentLabel(field).toLowerCase()} securely…`);
    const { data, error } = await supabase.storage.from("application-documents").download(objectPath);
    button.disabled = false;
    if (error) {
      if (documentWindow) documentWindow.close();
      setNotice(`Unable to access this private document: ${error.message}`, "error");
      return;
    }
    const objectUrl = URL.createObjectURL(data);
    if (documentWindow) {
      documentWindow.location.href = objectUrl;
    } else {
      const link = document.createElement("a");
      link.href = objectUrl;
      link.download = String(objectPath).split("/").pop() || "application-document";
      document.body.append(link);
      link.click();
      link.remove();
    }
    window.setTimeout(() => URL.revokeObjectURL(objectUrl), 5 * 60 * 1000);
    setNotice("Document opened using authenticated private storage access.", "success");
  }

  async function signOut() {
    if (!session || !hasSupabaseAuth()) {
      showLogin("Your session is no longer available. Sign in again to continue.");
      return;
    }
    try {
      const { error } = await supabase.auth.signOut();
      if (error) {
        setNotice(friendlyAuthError(error, "signout"), "error");
        return;
      }
    } catch (error) {
      setNotice(friendlyAuthError(error, "signout"), "error");
      return;
    }
    session = null;
    applications = [];
    residences = [];
    showLogin();
  }

  function showConnectionUnavailable(message) {
    session = null;
    if (document.querySelector("#management-login")) {
      document.querySelector("#login-message").textContent = message;
    } else {
      showLogin(message);
    }
  }

  async function initialize() {
    if (initializing) return;
    initializing = true;
    if (!document.querySelector("#management-login") && !document.querySelector(".management-layout")) {
      showLogin("Connecting to the management workspace…");
    }
    const retryButton = document.querySelector("[data-retry-connection]");
    if (retryButton) retryButton.disabled = true;

    try {
      let configResponse;
      try {
        configResponse = await fetch("/api/config", { cache: "no-store" });
      } catch {
        showConnectionUnavailable("Live sign-in is temporarily unavailable. Check your connection and retry.");
        return;
      }
      if (!configResponse.ok) {
        let details;
        try {
          details = await configResponse.json();
        } catch {
          details = null;
        }
        showConnectionUnavailable(details && details.error
          ? "Live sign-in is temporarily unavailable. Retry the connection or contact the site administrator."
          : `Live sign-in is temporarily unavailable (configuration HTTP ${configResponse.status}). Retry the connection.`);
        return;
      }
      if (!window.supabase || typeof window.supabase.createClient !== "function") {
        showConnectionUnavailable("Live sign-in is temporarily unavailable because the connection library did not load. Retry the connection.");
        return;
      }

      let config;
      try {
        config = await configResponse.json();
      } catch {
        showConnectionUnavailable("Live sign-in is temporarily unavailable because its configuration could not be read. Retry the connection.");
        return;
      }
      if (typeof config.supabaseUrl !== "string" || !config.supabaseUrl
        || typeof config.supabasePublishableKey !== "string" || !config.supabasePublishableKey) {
        showConnectionUnavailable("Live sign-in is temporarily unavailable because its configuration is incomplete. Retry the connection.");
        return;
      }

      const sameConfig = supabase && supabaseConfig
        && supabaseConfig.url === config.supabaseUrl
        && supabaseConfig.key === config.supabasePublishableKey;
      if (!sameConfig) {
        if (authSubscription && typeof authSubscription.unsubscribe === "function") {
          authSubscription.unsubscribe();
        }
        authSubscription = null;
        supabase = null;
        try {
          supabase = window.supabase.createClient(config.supabaseUrl, config.supabasePublishableKey, {
            auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
          });
        } catch {
          showConnectionUnavailable("Live sign-in is temporarily unavailable because the connection could not be initialized. Retry the connection.");
          return;
        }
        supabaseConfig = { url: config.supabaseUrl, key: config.supabasePublishableKey };
      }
      if (!hasSupabaseAuth() || typeof supabase.auth.getSession !== "function"
        || typeof supabase.auth.onAuthStateChange !== "function"
        || typeof supabase.auth.signOut !== "function"
        || typeof supabase.auth.updateUser !== "function"
        || !hasSupabaseDataClient()) {
        supabase = null;
        supabaseConfig = null;
        showConnectionUnavailable("Live sign-in is temporarily unavailable because the connection did not initialize correctly. Retry the connection.");
        return;
      }

      if (!authSubscription) {
        const { data } = supabase.auth.onAuthStateChange((event, nextSession) => {
          if (event === "INITIAL_SESSION") return;
          window.setTimeout(async () => {
            try {
              if (!nextSession) {
                if (event === "SIGNED_OUT" && document.querySelector(".management-layout")) {
                  session = null;
                  showLogin("You have been logged out. Log in to continue.");
                }
                return;
              }
              if (event === "PASSWORD_RECOVERY") {
                if (!isManagementUser(nextSession.user)) {
                  const { error } = await supabase.auth.signOut();
                  showLogin(error
                    ? "This account is not authorised for management, and sign-out could not be completed. Contact an administrator."
                    : "This account is not authorised for management. Ask an administrator to provision access.");
                  return;
                }
                showPasswordRecovery(nextSession);
                return;
              }
              if (!isManagementUser(nextSession.user)) {
                const { error } = await supabase.auth.signOut();
                showLogin(error
                  ? "This account is not authorised for management, and sign-out could not be completed. Contact an administrator."
                  : "This account is not authorised for management. Ask an administrator to provision access.");
                return;
              }
              if (!session || session.user.id !== nextSession.user.id) {
                session = nextSession;
                await enterDashboard();
              } else {
                session = nextSession;
              }
            } catch (error) {
              showLogin(friendlyAuthError(error, "signin"));
            }
          }, 0);
        });
        authSubscription = data.subscription;
      }

      let sessionResult;
      try {
        sessionResult = await supabase.auth.getSession();
      } catch {
        showConnectionUnavailable("Your login could not be verified. Retry the connection before logging in.");
        return;
      }
      const { data, error } = sessionResult;
      if (error) {
        showConnectionUnavailable("Your login could not be verified. Retry the connection before logging in.");
        return;
      }
      session = data.session;
      if (!session) {
        showLogin();
      } else if (!isManagementUser(session.user)) {
        const { error: signOutError } = await supabase.auth.signOut();
        showLogin(signOutError
          ? "This account is not authorised for management, and sign-out could not be completed. Contact an administrator."
          : "This account is not authorised for management. Ask an administrator to provision access.");
      } else {
        await enterDashboard();
      }
    } finally {
      initializing = false;
      const activeRetryButton = document.querySelector("[data-retry-connection]");
      if (activeRetryButton) activeRetryButton.disabled = false;
    }
  }

  app.addEventListener("click", (event) => {
    if (event.target.closest("[data-retry-connection]")) initialize();
  });

  initialize();
})();
