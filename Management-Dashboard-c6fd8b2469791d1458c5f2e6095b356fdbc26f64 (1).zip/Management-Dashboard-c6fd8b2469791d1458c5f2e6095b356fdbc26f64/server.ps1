$ErrorActionPreference = "Stop"

$listener = [System.Net.HttpListener]::new()
$listener.Prefixes.Add("http://localhost:3000/")
$listener.Start()
Write-Host "Student Heights management workspace available at http://localhost:3000/"

$files = @{
    "/" = @("index.html", "text/html; charset=utf-8")
    "/login" = @("index.html", "text/html; charset=utf-8")
    "/demo" = @("index.html", "text/html; charset=utf-8")
    "/index.html" = @("index.html", "text/html; charset=utf-8")
    "/styles.css" = @("styles.css", "text/css; charset=utf-8")
    "/app.js" = @("app.js", "text/javascript; charset=utf-8")
    "/management.js" = @("management.js", "text/javascript; charset=utf-8")
    "/images/Logo.jpg" = @("images\Logo.jpg", "image/jpeg")
}

try {
    while ($listener.IsListening) {
        $context = $listener.GetContext()
        $path = $context.Request.Url.AbsolutePath
        $response = $context.Response

        if ($path -eq "/api/config") {
            if ($context.Request.HttpMethod -ne "GET") {
                $response.StatusCode = 405
                $response.Headers.Add("Allow", "GET")
                $response.Close()
                continue
            }

            $supabaseUrl = $env:SUPABASE_URL
            $publishableKey = $env:SUPABASE_PUBLISHABLE_KEY
            $isPublicKey = $false
            if ($publishableKey -and $publishableKey.StartsWith("sb_publishable_", [System.StringComparison]::Ordinal)) {
                $isPublicKey = $true
            } elseif ($publishableKey) {
                try {
                    $parts = $publishableKey.Split(".")
                    if ($parts.Length -eq 3) {
                        $payload = $parts[1].Replace("-", "+").Replace("_", "/")
                        $payload += "=" * ((4 - ($payload.Length % 4)) % 4)
                        $claims = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($payload)) | ConvertFrom-Json
                        $isPublicKey = $claims.role -eq "anon"
                    }
                } catch {
                    $isPublicKey = $false
                }
            }
            $response.Headers.Add("Cache-Control", "no-store")
            $response.Headers.Add("X-Content-Type-Options", "nosniff")
            $response.ContentType = "application/json; charset=utf-8"
            if (-not $supabaseUrl -or -not $publishableKey) {
                $response.StatusCode = 503
                $body = @{ error = "Set SUPABASE_URL and SUPABASE_PUBLISHABLE_KEY before starting the local server." } | ConvertTo-Json -Compress
            } elseif ($supabaseUrl.TrimEnd("/") -ne "https://iklpdshgmrtkkufwcbfv.supabase.co") {
                $response.StatusCode = 503
                $body = @{ error = "SUPABASE_URL must point to the confirmed Student Heights Supabase project." } | ConvertTo-Json -Compress
            } elseif (-not $isPublicKey) {
                $response.StatusCode = 503
                $body = @{ error = "SUPABASE_PUBLISHABLE_KEY must be a publishable or anon key, never a service-role key." } | ConvertTo-Json -Compress
            } else {
                $response.StatusCode = 200
                $body = @{ supabaseUrl = $supabaseUrl; supabasePublishableKey = $publishableKey } | ConvertTo-Json -Compress
            }
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($body)
            $response.ContentLength64 = $bytes.Length
            if ($context.Request.HttpMethod -eq "GET") {
                $response.OutputStream.Write($bytes, 0, $bytes.Length)
            }
            $response.Close()
            continue
        }

        if (-not $files.ContainsKey($path)) {
            $response.StatusCode = 404
            $response.ContentType = "text/plain; charset=utf-8"
            $bytes = [System.Text.Encoding]::UTF8.GetBytes("Not found")
            $response.ContentLength64 = $bytes.Length
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
            $response.Close()
            continue
        }

        if ($context.Request.HttpMethod -notin @("GET", "HEAD")) {
            $response.StatusCode = 405
            $response.Headers.Add("Allow", "GET, HEAD")
            $response.Close()
            continue
        }

        $file = Join-Path $PSScriptRoot $files[$path][0]
        try {
            $bytes = [System.IO.File]::ReadAllBytes($file)
        } catch {
            Write-Error "Unable to read $file`: $($_.Exception.Message)"
            $response.StatusCode = 500
            $response.ContentType = "text/plain; charset=utf-8"
            $bytes = [System.Text.Encoding]::UTF8.GetBytes("Unable to load the workspace.")
        }
        $response.ContentType = $files[$path][1]
        $response.Headers.Add("X-Content-Type-Options", "nosniff")
        $response.Headers.Add("Referrer-Policy", "no-referrer")
        $response.Headers.Add("Cache-Control", "no-store")
        $response.ContentLength64 = $bytes.Length
        if ($context.Request.HttpMethod -eq "GET") {
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
        }
        $response.Close()
    }
} finally {
    $listener.Stop()
    $listener.Close()
}
