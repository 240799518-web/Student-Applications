﻿-- Additive email-delivery tracking for application submission and status notifications.
-- Run in the Supabase SQL Editor after confirming public.applications exists.

create table if not exists public.application_email_notifications (
  application_id uuid not null references public.applications(id) on delete cascade,
  notification_type text not null check (notification_type in (
    'student_confirmation',
    'management_alert',
    'status_under_review',
    'status_approved',
    'status_rejected'
  )),
  recipient_email text,
  application_status text check (application_status is null or application_status in ('submitted', 'under_review', 'approved', 'rejected')),
  status text not null default 'pending' check (status in ('pending', 'sending', 'sent', 'failed')),
  attempt_count integer not null default 0 check (attempt_count between 0 and 3),
  claimed_at timestamptz,
  sent_at timestamptz,
  provider_id text,
  last_error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (application_id, notification_type)
);

alter table public.application_email_notifications enable row level security;
revoke all on public.application_email_notifications from public, anon, authenticated;
grant select, insert, update on public.application_email_notifications to service_role;

alter table public.application_email_notifications
  add column if not exists recipient_email text,
  add column if not exists application_status text;

alter table public.application_email_notifications
  drop constraint if exists application_email_notifications_notification_type_check,
  add constraint application_email_notifications_notification_type_check
    check (notification_type in (
      'student_confirmation',
      'management_alert',
      'status_under_review',
      'status_approved',
      'status_rejected'
    )),
  drop constraint if exists application_email_notifications_application_status_check,
  add constraint application_email_notifications_application_status_check
    check (application_status is null or application_status in ('submitted', 'under_review', 'approved', 'rejected'));

drop function if exists public.claim_application_email_notification(uuid, text);

create or replace function public.claim_application_email_notification(
  p_application_id uuid,
  p_notification_type text,
  p_recipient_email text,
  p_application_status text
)
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
  claimed boolean;
begin
  if coalesce((select auth.role()), '') <> 'service_role' then
    raise exception 'Service role access is required';
  end if;

  if p_notification_type not in (
    'student_confirmation',
    'management_alert',
    'status_under_review',
    'status_approved',
    'status_rejected'
  ) then
    raise exception 'Invalid notification type';
  end if;

  if p_recipient_email !~* '^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$'
    or p_application_status not in ('submitted', 'under_review', 'approved', 'rejected') then
    raise exception 'Invalid notification recipient or application status';
  end if;

  insert into public.application_email_notifications (
    application_id,
    notification_type,
    recipient_email,
    application_status
  )
  values (p_application_id, p_notification_type, p_recipient_email, p_application_status)
  on conflict (application_id, notification_type) do nothing;

  update public.application_email_notifications
  set status = 'sending',
      attempt_count = attempt_count + 1,
      claimed_at = now(),
      updated_at = now(),
      recipient_email = p_recipient_email,
      application_status = p_application_status,
      last_error = null
  where application_id = p_application_id
    and notification_type = p_notification_type
    and attempt_count < 3
    and (
      status in ('pending', 'failed')
      or (status = 'sending' and claimed_at < now() - interval '5 minutes')
    )
  returning true into claimed;

  return coalesce(claimed, false);
end;
$$;

create or replace function public.complete_application_email_notification(
  p_application_id uuid,
  p_notification_type text,
  p_provider_id text,
  p_error text
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if coalesce((select auth.role()), '') <> 'service_role' then
    raise exception 'Service role access is required';
  end if;

  if p_notification_type not in (
    'student_confirmation',
    'management_alert',
    'status_under_review',
    'status_approved',
    'status_rejected'
  ) then
    raise exception 'Invalid notification type';
  end if;

  update public.application_email_notifications
  set status = case when p_error is null then 'sent' else 'failed' end,
      sent_at = case when p_error is null then now() else null end,
      provider_id = case when p_error is null then p_provider_id else null end,
      last_error = left(p_error, 500),
      updated_at = now()
  where application_id = p_application_id
    and notification_type = p_notification_type
    and status = 'sending';

  if not found then
    raise exception 'Notification is not currently claimed';
  end if;
end;
$$;

revoke all on function public.claim_application_email_notification(uuid, text, text, text) from public, anon, authenticated;
grant execute on function public.claim_application_email_notification(uuid, text, text, text) to service_role;
revoke all on function public.complete_application_email_notification(uuid, text, text, text) from public, anon, authenticated;
grant execute on function public.complete_application_email_notification(uuid, text, text, text) to service_role;
