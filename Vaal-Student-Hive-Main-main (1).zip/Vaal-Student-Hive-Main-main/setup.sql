-- Review the existing Supabase schema and data before running this script.
-- Enable email auth and allow this site's URLs under Authentication > URL Configuration.

create table if not exists public.residences (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  images text[] not null default '{}',
  address text,
  available_rooms integer check (available_rooms is null or available_rooms >= 0),
  created_at timestamptz not null default now()
);

create table if not exists public.applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  first_name text not null,
  surname text not null,
  student_number text not null,
  email text not null,
  phone text not null,
  residence_name text not null references public.residences(name) on update cascade on delete restrict,
  move_in_date date not null,
  room_type text check (room_type is null or room_type in ('Single room', 'Shared room')),
  created_at timestamptz not null default now()
);

-- Keep previously submitted rows intact while allowing a validated draft to be saved in stages.
alter table public.applications
  add column if not exists application_reference text,
  add column if not exists status text,
  add column if not exists submitted_at timestamptz,
  add column if not exists proof_of_registration_path text,
  add column if not exists proof_of_funding_path text,
  add column if not exists identity_document_path text,
  add column if not exists privacy_consent_at timestamptz,
  alter column first_name drop not null,
  alter column surname drop not null,
  alter column student_number drop not null,
  alter column email drop not null,
  alter column phone drop not null,
  alter column residence_name drop not null,
  alter column move_in_date drop not null;

update public.applications
set status = 'submitted',
    application_reference = 'VSH-' || upper(replace(id::text, '-', '')),
    submitted_at = coalesce(submitted_at, created_at)
where status is null or application_reference is null;

update public.applications
set submitted_at = coalesce(submitted_at, created_at)
where status in ('submitted', 'under_review', 'approved', 'rejected')
  and submitted_at is null;

alter table public.applications
  alter column application_reference set default ('VSH-' || upper(replace(gen_random_uuid()::text, '-', ''))),
  alter column application_reference set not null,
  alter column status set default 'draft',
  alter column status set not null;

alter table public.applications
  drop constraint if exists applications_status_check,
  add constraint applications_status_check
    check (status in ('draft', 'submitted', 'under_review', 'approved', 'rejected')),
  drop constraint if exists applications_submitted_complete_check,
  add constraint applications_submitted_complete_check
    check (
      status <> 'submitted'
      or (
        first_name is not null and length(trim(first_name)) > 0
        and surname is not null and length(trim(surname)) > 0
        and student_number is not null and length(trim(student_number)) > 0
        and email is not null and length(trim(email)) > 0
        and phone is not null and length(trim(phone)) > 0
        and residence_name is not null
        and move_in_date is not null
        and (room_type is null or room_type in ('Single room', 'Shared room'))
        and proof_of_registration_path is not null
        and proof_of_funding_path is not null
        and identity_document_path is not null
        and submitted_at is not null
        and privacy_consent_at is not null
      )
    ) not valid;

create index if not exists applications_user_created_at_idx
  on public.applications (user_id, created_at desc);
create unique index if not exists applications_reference_unique_idx
  on public.applications (application_reference);

alter table public.residences enable row level security;
alter table public.applications enable row level security;

create or replace function public.is_verified_student()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from auth.users
    where id = (select auth.uid())
      and email_confirmed_at is not null
  );
$$;

revoke all on function public.is_verified_student() from public;
grant execute on function public.is_verified_student() to authenticated;

drop policy if exists "Residences are viewable by everyone" on public.residences;
create policy "Residences are viewable by everyone"
  on public.residences for select
  to anon, authenticated
  using (true);

drop policy if exists "Users can submit their own applications" on public.applications;
create policy "Users can submit their own applications"
  on public.applications for insert
  to authenticated
  with check (
    (select auth.uid()) = user_id
    and (select public.is_verified_student())
    and status = 'draft'
  );

drop policy if exists "Users can view their own applications" on public.applications;
create policy "Users can view their own applications"
  on public.applications for select
  to authenticated
  using (
    (select auth.uid()) = user_id
    and (select public.is_verified_student())
  );

drop policy if exists "Verified students can update their own applications" on public.applications;
create policy "Verified students can update their own applications"
  on public.applications for update
  to authenticated
  using (
    (select auth.uid()) = user_id
    and (select public.is_verified_student())
    and status = 'draft'
  )
  with check (
    (select auth.uid()) = user_id
    and (select public.is_verified_student())
    and status = 'draft'
  );

drop policy if exists "Management can review applications" on public.applications;
create policy "Management can review applications"
  on public.applications for select
  to authenticated
  using ((select auth.jwt() -> 'app_metadata' ->> 'role') = 'management');

drop policy if exists "Management can update application status" on public.applications;
create policy "Management can update application status"
  on public.applications for update
  to authenticated
  using ((select auth.jwt() -> 'app_metadata' ->> 'role') = 'management')
  with check ((select auth.jwt() -> 'app_metadata' ->> 'role') = 'management');

grant select on public.residences to anon, authenticated;
revoke insert, update on public.applications from authenticated;
grant select on public.applications to authenticated;
grant insert (user_id, status) on public.applications to authenticated;
grant update (
  first_name,
  surname,
  student_number,
  email,
  phone,
  residence_name,
  move_in_date,
  room_type,
  proof_of_registration_path,
  proof_of_funding_path,
  identity_document_path
) on public.applications to authenticated;

drop function if exists public.submit_student_application(uuid);

create or replace function public.submit_student_application(
  p_application_id uuid,
  p_privacy_consent boolean
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  updated_application public.applications;
begin
  if (select auth.uid()) is null or not (select public.is_verified_student()) then
    raise exception 'Verified student authentication is required';
  end if;

  if p_privacy_consent is distinct from true then
    raise exception 'Student privacy consent is required';
  end if;

  update public.applications as a
  set status = 'submitted',
      submitted_at = now(),
      privacy_consent_at = now()
  where a.id = p_application_id
    and a.user_id = (select auth.uid())
    and a.status = 'draft'
    and nullif(trim(a.first_name), '') is not null
    and nullif(trim(a.surname), '') is not null
    and nullif(trim(a.student_number), '') is not null
    and nullif(trim(a.email), '') is not null
    and nullif(trim(a.phone), '') is not null
    and a.residence_name is not null
    and a.move_in_date is not null
    and a.proof_of_registration_path is not null
    and a.proof_of_funding_path is not null
    and a.identity_document_path is not null
  returning a.* into updated_application;

  if not found then
    raise exception 'Application is incomplete or is no longer an editable draft';
  end if;

  return to_jsonb(updated_application);
end;
$$;

revoke all on function public.submit_student_application(uuid, boolean) from public;
grant execute on function public.submit_student_application(uuid, boolean) to authenticated;

create or replace function public.management_set_application_status(
  p_application_id uuid,
  p_status text
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  updated_application public.applications;
begin
  if (select auth.uid()) is null
    or coalesce((select auth.jwt() -> 'app_metadata' ->> 'role'), '') <> 'management' then
    raise exception 'Authorized management access is required';
  end if;

  if p_status not in ('under_review', 'approved', 'rejected') then
    raise exception 'Invalid management application status';
  end if;

  update public.applications as a
  set status = p_status
  where a.id = p_application_id
    and a.status in ('submitted', 'under_review')
  returning a.* into updated_application;

  if not found then
    raise exception 'Application is not available for this status change';
  end if;

  return to_jsonb(updated_application);
end;
$$;

revoke all on function public.management_set_application_status(uuid, text) from public;
grant execute on function public.management_set_application_status(uuid, text) to authenticated;

-- Private files use user-id/application-id object paths; never expose this bucket publicly.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'application-documents',
  'application-documents',
  false,
  10485760,
  array['application/pdf', 'image/jpeg', 'image/png']
)
on conflict (id) do update
set public = false,
    file_size_limit = excluded.file_size_limit,
    allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "Students upload documents to their own drafts" on storage.objects;
create policy "Students upload documents to their own drafts"
  on storage.objects for insert
  to authenticated
  with check (
    bucket_id = 'application-documents'
    and (storage.foldername(name))[1] = (select auth.uid())::text
    and exists (
      select 1 from public.applications a
      where a.id::text = (storage.foldername(name))[2]
        and a.user_id = (select auth.uid())
        and a.status = 'draft'
        and (select public.is_verified_student())
    )
    and metadata->>'mimetype' in ('application/pdf', 'image/jpeg', 'image/png')
    and (metadata->>'size')::bigint <= 10485760
  );

drop policy if exists "Students read their own documents" on storage.objects;
create policy "Students read their own documents"
  on storage.objects for select
  to authenticated
  using (
    bucket_id = 'application-documents'
    and (storage.foldername(name))[1] = (select auth.uid())::text
    and exists (
      select 1 from public.applications a
      where a.id::text = (storage.foldername(name))[2]
        and a.user_id = (select auth.uid())
        and (select public.is_verified_student())
    )
  );

drop policy if exists "Students replace documents on their own drafts" on storage.objects;
create policy "Students replace documents on their own drafts"
  on storage.objects for delete
  to authenticated
  using (
    bucket_id = 'application-documents'
    and (storage.foldername(name))[1] = (select auth.uid())::text
    and exists (
      select 1 from public.applications a
      where a.id::text = (storage.foldername(name))[2]
        and a.user_id = (select auth.uid())
        and a.status = 'draft'
        and (select public.is_verified_student())
    )
  );

drop policy if exists "Management can read student documents" on storage.objects;
create policy "Management can read student documents"
  on storage.objects for select
  to authenticated
  using (
    bucket_id = 'application-documents'
    and (select auth.jwt() -> 'app_metadata' ->> 'role') = 'management'
  );

insert into public.residences (name, images, available_rooms)
values
  ('18 On Demeter', array['images/18On-Demter.jpg']::text[], null),
  ('4Anthenia Student Accommodation', array['images/4Anthenia.jpg', 'images/4Anthenia-1.jpg', 'images/4Anthenia-2.jpg', 'images/4Anthenia-3.jpg', 'images/4Anthenia-4.jpg', 'images/4anthenia-5.jpg']::text[], null),
  ('9@Wellies Student Accommodation', array['images/9@Wellies.jpg', 'images/9@Wellies-1.jpg', 'images/9@Wellies-2.jpg', 'images/9@Wellies-3.jpg']::text[], null),
  ('Bovua@17Helious', array['images/17Helious.jpg', 'images/17Helious-1.jpg', 'images/17Helious-2.jpg']::text[], null),
  ('Bovua@2Bellona', array['images/10Bellona.jpg', 'images/10Bellona-1.jpg', 'images/10Bellona-2.jpg', 'images/10Bellona-3.jpg', 'images/10Bellona-4.jpg', 'images/10Bellona-5.jpg', 'images/10Bellona-6.jpg', 'images/10Bellona-7.jpg', 'images/10Bellona-8.jpg', 'images/10Bellona-9.jpg', 'images/10Bellona-10.jpg', 'images/10Bellona-11.jpg']::text[], null),
  ('Bovua@36Aurora', array['images/36Aurora.jpg']::text[], null),
  ('Bovua@Borea Student Accommodation', array['images/Borea.jpg']::text[], null),
  ('Bovua@16Fortuna', array['images/16Fortune.jpg', 'images/16Fortune-1.jpg', 'images/16Fortune-2.jpg', 'images/16Fortune-3.jpg', 'images/16Fortune-4.jpg']::text[], null),
  ('Bovua@22Penelope', array['images/22Penelope.jpg']::text[], null),
  ('Bovua@39Galatea', array['images/39Galatea.jpg']::text[], null),
  ('Bovua@45Penelope', array['images/45Penelope.jpg']::text[], null),
  ('Bovua Student Accommodation Bovua@21', array['images/Bovua.jpg']::text[], null),
  ('Koeneng Student Accommodation', array['images/Koeneng.jpg']::text[], null),
  ('Lefari Student Accommodation', array['images/Lefari.jpg', 'images/Lefari-1.jpg', 'images/Lefari-2.jpg', 'images/Lefari-3.jpg', 'images/Lefari-4.jpg', 'images/Lefari-5.jpg']::text[], null),
  ('Lima Student Accommodation', array['images/Lima.jpg']::text[], null),
  ('Lufuno Student Accommodation', array['images/Lufuno.jpg']::text[], null),
  ('MNM2 Student Accommodation', array['images/MNM2.JPG']::text[], null),
  ('1999 Student Accommodation', array['images/1999.jpg']::text[], null),
  ('Queens', array['images/Queens.jpg']::text[], null),
  ('Bovua@18Bellona', array['images/18Bellona.jpg', 'images/18Bellona-1.jpg', 'images/18Bellona-2.jpg']::text[], null),
  ('Bovua@19Hector', array['images/19Hector.jpg']::text[], null),
  ('Bovua@1Ganymade', array['images/1Ganymade.jpg']::text[], null),
  ('Bovua@28Anthenia', array['images/28Anthenia.jpg']::text[], null)
on conflict (name) do nothing;
