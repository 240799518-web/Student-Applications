import { cp, mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const output = join(root, "dist");

async function loadLocalEnvironment() {
  let contents;
  try {
    contents = await readFile(join(root, ".env"), "utf8");
  } catch (error) {
    if (error.code === "ENOENT") return;
    throw error;
  }

  for (const line of contents.split(/\r?\n/)) {
    const entry = line.trim();
    if (!entry || entry.startsWith("#")) continue;
    const separator = entry.indexOf("=");
    if (separator < 1) continue;
    const name = entry.slice(0, separator).trim();
    let value = entry.slice(separator + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    if (!process.env[name]) process.env[name] = value;
  }
}

await loadLocalEnvironment();

const expectedSupabaseUrl = "https://iklpdshgmrtkkufwcbfv.supabase.co";
const configuredSupabaseUrl = process.env.SUPABASE_URL?.trim();
const supabaseUrl = configuredSupabaseUrl || expectedSupabaseUrl;
const defaultSupabasePublishableKey = "sb_publishable_toLzVw2y0duO5NI6pz0vrA_IY1hIl6R";
const supabasePublishableKey = process.env.SUPABASE_PUBLISHABLE_KEY?.trim() || defaultSupabasePublishableKey;

if (/^(?:PASTE_MY_SUPABASE_PUBLISHABLE_KEY_HERE|your_supabase_publishable_key)$/i.test(supabasePublishableKey)) {
  throw new Error("SUPABASE_PUBLISHABLE_KEY must be a valid publishable key.");
}

function isServiceRoleKey(key) {
  if (/^sb_secret_/i.test(key)) return true;
  const parts = key.split(".");
  if (parts.length !== 3) return false;
  try {
    const claims = JSON.parse(Buffer.from(parts[1], "base64url").toString("utf8"));
    return claims.role === "service_role";
  } catch {
    return false;
  }
}

if (isServiceRoleKey(supabasePublishableKey)) {
  throw new Error("SUPABASE_PUBLISHABLE_KEY must not contain a service-role or secret key.");
}

let parsedUrl;
try {
  parsedUrl = new URL(supabaseUrl);
} catch {
  throw new Error("SUPABASE_URL must be a valid absolute URL.");
}

if (parsedUrl.protocol !== "https:" && parsedUrl.hostname !== "localhost" && parsedUrl.hostname !== "127.0.0.1") {
  throw new Error("SUPABASE_URL must use HTTPS, except for a local Supabase development instance.");
}
if (process.env.VERCEL && (parsedUrl.hostname === "localhost" || parsedUrl.hostname === "127.0.0.1")) {
  throw new Error(`SUPABASE_URL must point to ${expectedSupabaseUrl} when building on Vercel.`);
}
if (
  (parsedUrl.origin !== expectedSupabaseUrl && parsedUrl.hostname !== "localhost" && parsedUrl.hostname !== "127.0.0.1")
  || parsedUrl.pathname !== "/"
  || parsedUrl.search
  || parsedUrl.hash
) {
  throw new Error(`SUPABASE_URL must point to ${expectedSupabaseUrl} (or a local development instance).`);
}

await rm(output, { recursive: true, force: true });
await mkdir(output, { recursive: true });

for (const file of ["index.html", "app.js", "styles.css", "robots.txt", "sitemap.xml"]) {
  await cp(join(root, file), join(output, file));
}
const managementOutput = join(output, "management");
await mkdir(managementOutput, { recursive: true });
for (const file of ["index.html", "management.js", "style.css"]) {
  await cp(join(root, "Management-Dashboard", file), join(managementOutput, file));
}
const homepageVideo = join(root, "images", "videos", "2 Bellona-10s.mp4");
await cp(join(root, "images"), join(output, "images"), {
  recursive: true,
  filter: (source) => !source.toLowerCase().endsWith(".mp4") || resolve(source) === homepageVideo
});

const publicConfiguration = {
  supabaseUrl: parsedUrl.origin,
  supabasePublishableKey
};
await writeFile(
  join(output, "config.js"),
  `window.VSH_CONFIG = Object.freeze(${JSON.stringify(publicConfiguration)});\n`,
  "utf8"
);

console.log("Static site built in dist/.");
