const SUPABASE_URL = window.VSH_CONFIG?.supabaseUrl || "https://iklpdshgmrtkkufwcbfv.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = window.VSH_CONFIG?.supabasePublishableKey || "sb_publishable_toLzVw2y0duO5NI6pz0vrA_IY1hIl6R";
const supabaseUnavailableMessage = !window.supabase
  ? "The Supabase library did not load. Check your internet connection or CDN access, then reload this page."
  : !SUPABASE_URL || !SUPABASE_PUBLISHABLE_KEY
    ? "Supabase is not configured. Add the project URL and publishable key to the build environment, then rebuild and redeploy. Use the publishable key, never a service-role key."
    : "";
const supabaseClient = window.supabase && SUPABASE_URL && SUPABASE_PUBLISHABLE_KEY
  ? window.supabase.createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
    auth: {
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: false,
      flowType: "pkce"
    }
  })
  : null;
let residences = [];
let currentUser = null;
let currentSession = null;
let authReady = false;
let authenticationInitialization = Promise.resolve();
let authView = "register";
let pendingVerificationEmail = "";
let verificationLinkError = false;
let showAuthDuringVerification = false;
let passwordRecoveryInProgress = false;
let applicationRecord = null;
let applicationFormOpen = false;
let autoOpenApplication = false;
let openMyApplications = false;
let pendingApplicationAfterSignIn = false;
let pendingApplicationResidence = "";
let pendingApplicationUniversity = "";
let pendingApplicationStartNew = false;
let selectedApplicationUniversity = "";
let residenceToApplyFor = "";
let residenceApplicationStartNew = false;
let isSubmittingApplication = false;
const maximumDocumentSize = 10 * 1024 * 1024;
const allowedDocumentTypes = new Set(["application/pdf", "image/jpeg", "image/png"]);
const documentFields = [
  { input: "proofOfRegistration", column: "proof_of_registration_path", label: "Proof of Registration" },
  { input: "proofOfFunding", column: "proof_of_funding_path", label: "Proof of Funding" },
  { input: "identityDocument", column: "identity_document_path", label: "Identity document" }
];
const managementTeam = [
  { id: "lwazi", name: "Lwazi Nene", position: "CEO of Vaal Student Hive", image: "images/Lwazi-Nene.jpg", email: "info@langalesedi", phone: "", biography: "" },
  { id: "moeketsi", name: "Moeketsi Mofokeng", position: "Founder & COO", image: "images/Moeketsi-Mofokeng.jpg", email: "info@langalesedi", phone: "", biography: "" },
  { id: "neo", name: "Neo Molotsi", position: "Operations Manager", image: "images/Neo-Molotsi.jpg", email: "neo.molotsi@langalesedi", phone: "", biography: "" },
  { id: "zama", name: "Zama Mnxeba", position: "Administrative Officer", image: "images/Zama-Mnxeba.jpg", email: "admin@student heights.coza", phone: "", biography: "" },
  { id: "nkosana", name: "Nkosana Macatywe", position: "Financial Administrator", image: "images/Nkosana-Macatywe.jpg", email: "finace@studentheights.co.za", phone: "", biography: "" },
  { id: "phemelo", name: "Phemelo Machidza", position: "Marketing & Stakeholder Relations", image: "images/Phemelo-Machidza.jpg", email: "phemelo.machidza@studentheights.coza", phone: "", biography: "" }
];

const tenBellonaResidenceImages = Array.from({ length: 12 }, (_, index) => (
  index === 0 ? "images/10Bellona.jpg" : `images/10Bellona-${index}.jpg`
));
const auroraResidenceImages = Array.from({ length: 9 }, (_, index) => (
  index === 0 ? "images/Aurora.jpg" : `images/Aurora-${index}.jpg`
));
const featuredResidenceOrder = [
  "Bovua@1Ganymade",
  "Bovua@2Bellona",
  "Bovua@36Aurora",
  "4Anthenia Student Accommodation"
];
const vutResidenceNames = new Set(["Queens", "Bovua@17Helious"]);
const universityDirectory = {
  vut: { name: "Vaal University of Technology", shortName: "VUT", logo: "images/Vut.logo.jpg" },
  nwu: { name: "North-West University", shortName: "NWU", logo: "images/Nwu.logo.png" }
};
const oneGanymadePhotoCategories = [
  { name: "Overview", images: ["images/1Ganymade.jpg", "images/10Bellona.jpg", "images/10Bellona-4.jpg", "images/1Ganymade-6.jpg"] },
  { name: "Bedroom", images: ["images/1Ganymade-8.jpg"] },
  { name: "Kitchen", images: ["images/1Ganymade-11.jpg", "images/1Ganymade-12.jpg"] },
  { name: "Bathroom", images: [] },
  { name: "Study Area", images: ["images/1Ganymade-7.jpg"] },
  { name: "Facilities", images: ["images/1Ganymade-3.jpg", "images/1Ganymade-4.jpg", "images/1Ganymade-5.jpg", "images/1Ganymade-9.jpg", "images/1Ganymade-10.jpg", "images/1Ganymade-13.jpg"] }
];
const tenBellonaPhotoCategories = [
  { name: "Overview", images: ["images/10Bellona.jpg", "images/10Bellona-4.jpg"] },
  { name: "Bedroom", images: ["images/10Bellona-8.jpg", "images/10Bellona-9.jpg", "images/10Bellona-11.jpg"] },
  { name: "Kitchen", images: ["images/10Bellona-1.jpg", "images/10Bellona-2.jpg", "images/10Bellona-3.jpg"] },
  { name: "Bathroom", images: [] },
  { name: "Study Area", images: ["images/10Bellona-10.jpg"] },
  { name: "Facilities", images: ["images/10Bellona-5.jpg", "images/10Bellona-6.jpg", "images/10Bellona-7.jpg"] }
];
const oneGanymadeResidenceImages = oneGanymadePhotoCategories.flatMap((category) => category.images);
const fallbackResidences = [
  { name: "18 On Demeter", images: ["images/18On-Demter.jpg"] },
  { name: "4Anthenia Student Accommodation", images: ["images/4Anthenia.jpg", "images/4Anthenia-1.jpg", "images/4Anthenia-2.jpg", "images/4Anthenia-3.jpg", "images/4Anthenia-4.jpg", "images/4anthenia-5.jpg"] },
  { name: "9@Wellies Student Accommodation", images: ["images/9@Wellies.jpg", "images/9@Wellies-1.jpg", "images/9@Wellies-2.jpg", "images/9@Wellies-3.jpg"] },
  { name: "Bovua@2Bellona", images: tenBellonaResidenceImages },
  { name: "Bovua@17Helious", images: ["images/17Helious.jpg", "images/17Helious-1.jpg", "images/17Helious-2.jpg"] },
  { name: "Bovua@36Aurora", images: auroraResidenceImages },
  { name: "Bovua@Borea Student Accommodation", images: ["images/Borea.jpg"] },
  { name: "Bovua@16Fortuna", images: ["images/16Fortune.jpg", "images/16Fortune-1.jpg", "images/16Fortune-2.jpg", "images/16Fortune-3.jpg", "images/16Fortune-4.jpg"] },
  { name: "Bovua@22Penelope", images: ["images/22Penelope.jpg"] },
  { name: "Bovua@39Galatea", images: ["images/39Galatea.jpg"] },
  { name: "Bovua@45Penelope", images: ["images/45Penelope.jpg"] },
  { name: "Bovua Student Accommodation Bovua@21", images: ["images/Bovua.jpg"] },
  { name: "Koeneng Student Accommodation", images: ["images/Koeneng.jpg"] },
  { name: "Lefari Student Accommodation", images: ["images/Lefari.jpg", "images/Lefari-1.jpg", "images/Lefari-2.jpg", "images/Lefari-3.jpg", "images/Lefari-4.jpg"] },
  { name: "Lima Student Accommodation", images: ["images/Lima.jpg"] },
  { name: "Lufuno Student Accommodation", images: ["images/Lufuno.jpg"] },
  { name: "MNM2 Student Accommodation", images: ["images/MNM2.JPG"] },
  { name: "1999 Student Accommodation", images: ["images/1999.jpg"] },
  { name: "Queens", images: ["images/Queens.jpg"] },
  { name: "Bovua@18Bellona", images: ["images/18Bellona.jpg", "images/18Bellona-1.jpg", "images/18Bellona-2.jpg"] },
  { name: "Bovua@19Hector", images: ["images/19Hector.jpg"] },
  { name: "Bovua@1Ganymade", images: oneGanymadeResidenceImages },
  { name: "Bovua@28Anthenia", images: ["images/28Anthenia.jpg"] }
];
const removedResidenceNames = new Set([
  "Langelihle Student Accommodation",
  "Leep City Student Accommodation",
  "Lora Student Accommodation",
  "Shakali Student Accommodation",
  "Bovua@26Anthenia"
]);
const grid = document.querySelector("#residence-grid");
const searchInput = document.querySelector("#residence-search");
const sortSelect = document.querySelector("#residence-sort");
const countLabel = document.querySelector("#results-count");
const residenceTotal = document.querySelector("#residence-total");
const emptyState = document.querySelector("#empty-state");
const teamProfileDialog = document.querySelector("#team-profile-dialog");
const teamProfileImage = document.querySelector("#team-profile-image");
const teamProfileName = document.querySelector("#team-profile-name");
const teamProfilePosition = document.querySelector("#team-profile-position");
const teamProfileBiography = document.querySelector("#team-profile-biography");
const teamProfileContactEmpty = document.querySelector("#team-profile-contact-empty");
const teamProfileEmail = document.querySelector("#team-profile-email");
const teamProfilePhone = document.querySelector("#team-profile-phone");
const teamProfileWhatsApp = document.querySelector("#team-profile-whatsapp");
let activeProfileTrigger = null;
const detailsDialog = document.querySelector("#details-dialog");
const detailsContent = document.querySelector("#details-content");
const directionsDialog = document.querySelector("#directions-dialog");
const directionsStatus = document.querySelector("#directions-status");
const directionsAddressNote = document.querySelector("#directions-address-note");
const directionsLink = document.querySelector("#google-maps-route");
const retryLocationButton = document.querySelector("#retry-location");
const locationHelp = document.querySelector("#location-help");
const applicationDialog = document.querySelector("#application-dialog");
const universityChoiceDialog = document.querySelector("#university-choice-dialog");
const applicationForm = document.querySelector("#application-form");
const authForms = document.querySelector("#auth-forms");
const registerForm = document.querySelector("#register-form");
const loginForm = document.querySelector("#login-form");
const recoveryForm = document.querySelector("#recovery-form");
const newPasswordForm = document.querySelector("#new-password-form");
const authStatus = document.querySelector("#auth-status");
const verificationPanel = document.querySelector("#verification-panel");
const signedInPanel = document.querySelector("#signed-in-panel");
const signedInEmail = document.querySelector("#signed-in-email");
const studentApplications = document.querySelector("#student-applications");
const applicationList = document.querySelector("#application-list");
const applicationListStatus = document.querySelector("#application-list-status");
const directoryStatus = document.querySelector("#directory-status");
const applicationStatus = document.querySelector("#application-status");
const applicationSuccessPanel = document.querySelector("#preview-complete");
const evidenceDialog = document.querySelector("#evidence-dialog");
const assistantPanel = document.querySelector("#assistant-panel");
const assistantMessages = document.querySelector("#assistant-messages");
const themeToggle = document.querySelector("#theme-toggle");
const themeLabel = document.querySelector("#theme-label");
const heroVideo = document.querySelector("#hero-video");
const pagination = document.querySelector("#residence-pagination");
const pageSize = 5;
let currentPage = 1;
let directionsDestination = "";
let directionsDestinationLabel = "";
let locationRequestId = 0;

function setStatus(element, message, isError = false) {
  element.textContent = message;
  element.classList.toggle("is-error", isError);
  element.hidden = !message;
}

function getApplicationSubmissionErrorMessage(error) {
  const detail = `${error?.code || ""} ${error?.message || ""}`.toLowerCase();
  if (detail.includes("verified student authentication")) {
    return "Your verified sign-in session has expired. Sign in again before submitting; your draft has been saved.";
  }
  if (detail.includes("incomplete") || detail.includes("no longer an editable draft")) {
    return "This application is incomplete or is no longer a draft. Refresh your application list and check its current status.";
  }
  if (detail.includes("submit_student_application") || detail.includes("pgrst202") || detail.includes("42883")) {
    return "Application submission is not configured correctly yet. Your draft is saved, but it has not been submitted. Please contact the website administrator.";
  }
  if (detail.includes("42501") || detail.includes("permission denied") || detail.includes("row-level security")) {
    return "The application service is not allowing this submission. Your draft is saved, but it has not been submitted. Please contact the website administrator.";
  }
  if (detail.includes("foreign key") || detail.includes("residence")) {
    return "The selected residence could not be matched to the application records. Your draft is saved; please select a listed residence and try again.";
  }
  return "Your draft was saved, but we could not confirm final submission. Check your application history before trying again.";
}

function setProfileContactLink(link, value, href) {
  link.hidden = !value;
  link.textContent = value || "";
  if (value) link.href = href;
  else link.removeAttribute("href");
}

function openTeamProfile(id, trigger) {
  const member = managementTeam.find((item) => item.id === id);
  if (!member) return;

  activeProfileTrigger = trigger;
  teamProfileImage.src = member.image;
  teamProfileImage.alt = member.name;
  teamProfileName.textContent = member.name;
  teamProfilePosition.textContent = member.position;
  teamProfileBiography.textContent = member.biography;
  teamProfileBiography.hidden = !member.biography;

  const hasContact = Boolean(member.email || member.phone);
  teamProfileContactEmpty.hidden = hasContact;
  setProfileContactLink(teamProfileEmail, member.email, `mailto:${member.email}`);
  setProfileContactLink(teamProfilePhone, member.phone, `tel:${member.phone.replace(/[^\d+]/g, "")}`);
  const internationalNumber = member.phone
    ? member.phone.replace(/\D/g, "").replace(/^0/, "27")
    : "";
  setProfileContactLink(
    teamProfileWhatsApp,
    internationalNumber ? `Message ${member.name} on WhatsApp` : "",
    internationalNumber ? `https://wa.me/${internationalNumber}` : ""
  );

  teamProfileDialog.showModal();
  document.querySelector("#close-team-profile").focus();
}

document.querySelectorAll("[data-open-profile]").forEach((button) => {
  button.addEventListener("click", () => openTeamProfile(button.dataset.openProfile, button));
});
document.querySelector("#close-team-profile").addEventListener("click", () => teamProfileDialog.close());
teamProfileDialog.addEventListener("cancel", (event) => {
  event.preventDefault();
  teamProfileDialog.close();
});
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && teamProfileDialog.open) teamProfileDialog.close();
});
teamProfileDialog.addEventListener("click", (event) => {
  if (event.target === teamProfileDialog) teamProfileDialog.close();
});
teamProfileDialog.addEventListener("close", () => {
  if (activeProfileTrigger?.isConnected) activeProfileTrigger.focus();
  activeProfileTrigger = null;
});

function setTheme(theme, persist = false) {
  const isDark = theme === "dark";
  document.body.dataset.theme = isDark ? "dark" : "bright";
  themeToggle.setAttribute("aria-pressed", String(isDark));
  themeToggle.setAttribute("aria-label", `Switch to ${isDark ? "bright" : "dark"} theme`);
  themeLabel.textContent = isDark ? "Bright theme" : "Dark theme";
  themeToggle.querySelector(".theme-icon").textContent = isDark ? "☀" : "◐";
  if (persist) localStorage.setItem("vaal-student-hive-theme", isDark ? "dark" : "bright");
}

setTheme(localStorage.getItem("vaal-student-hive-theme") === "dark" ? "dark" : "bright");
themeToggle.addEventListener("click", () => {
  setTheme(document.body.dataset.theme === "bright" ? "dark" : "bright", true);
});

if (heroVideo) {
  const reducedMotionPreference = window.matchMedia("(prefers-reduced-motion: reduce)");
  const updateHeroVideoPlayback = () => {
    if (reducedMotionPreference.matches || document.hidden) {
      heroVideo.pause();
      return;
    }
    heroVideo.play().catch((error) => {
      if (error.name !== "NotAllowedError") console.error("The homepage background video could not play.", error);
    });
  };
  updateHeroVideoPlayback();
  reducedMotionPreference.addEventListener("change", updateHeroVideoPlayback);
  document.addEventListener("visibilitychange", updateHeroVideoPlayback);
}

function getFilteredResidences() {
  const query = searchInput.value.trim().toLocaleLowerCase();
  const matches = residences.filter((residence) => residence.name.toLocaleLowerCase().includes(query));
  matches.sort((a, b) => {
    if (a.university !== b.university) return a.university === "vut" ? -1 : 1;
    if (sortSelect.value === "az") return a.name.localeCompare(b.name);
    if (sortSelect.value === "za") return b.name.localeCompare(a.name);
    const aIndex = featuredResidenceOrder.indexOf(a.name);
    const bIndex = featuredResidenceOrder.indexOf(b.name);
    return (aIndex < 0 ? featuredResidenceOrder.length : aIndex)
      - (bIndex < 0 ? featuredResidenceOrder.length : bIndex);
  });
  return matches;
}

function renderResidences() {
  const matches = getFilteredResidences();
  const pageCount = Math.ceil(matches.length / pageSize);
  currentPage = Math.max(1, Math.min(currentPage, pageCount || 1));
  const start = (currentPage - 1) * pageSize;
  const shown = matches.slice(start, start + pageSize);
  residenceTotal.textContent = String(residences.length);
  const cards = shown.map((residence, index) => {
    const card = document.createElement("article");
    card.className = "residence-card";
    card.dataset.residenceName = residence.name;
    card.style.animationDelay = `${Math.min(index, 7) * 65}ms`;

    const imageWrap = document.createElement("div");
    imageWrap.className = "card-image";
    imageWrap.setAttribute("role", "group");
    imageWrap.setAttribute("aria-label", `Photos of ${residence.name}`);
    const gallery = document.createElement("div");
    gallery.className = "card-gallery";
    gallery.tabIndex = 0;
    gallery.setAttribute("aria-label", `Scroll through photos of ${residence.name}`);
    const slides = residence.images.map((src, photoIndex) => {
      const slide = document.createElement("button");
      slide.className = "card-gallery-slide";
      slide.type = "button";
      slide.dataset.openResidence = residence.name;
      slide.dataset.photoIndex = String(photoIndex);
      slide.setAttribute("aria-label", `View photo ${photoIndex + 1} of ${residence.images.length} of ${residence.name}`);
      const image = document.createElement("img");
      image.src = src;
      image.alt = `${residence.name} photo ${photoIndex + 1}`;
      image.loading = photoIndex ? "lazy" : "eager";
      slide.append(image);
      return slide;
    });
    gallery.append(...slides);
    imageWrap.append(gallery);
    const number = document.createElement("span");
    number.className = "card-number";
    number.textContent = String(start + index + 1).padStart(2, "0");
    imageWrap.append(number);
    if (residence.images.length > 1) {
      const photoCount = document.createElement("span");
      photoCount.className = "card-photo-count";
      photoCount.setAttribute("aria-live", "polite");
      photoCount.textContent = `1 / ${residence.images.length}`;
      const previous = document.createElement("button");
      previous.className = "card-gallery-control card-gallery-previous";
      previous.type = "button";
      previous.dataset.cardGalleryStep = "-1";
      previous.setAttribute("aria-label", `Previous photo of ${residence.name}`);
      previous.textContent = "‹";
      const next = document.createElement("button");
      next.className = "card-gallery-control card-gallery-next";
      next.type = "button";
      next.dataset.cardGalleryStep = "1";
      next.setAttribute("aria-label", `Next photo of ${residence.name}`);
      next.textContent = "›";
      imageWrap.append(previous, next, photoCount);
      gallery.addEventListener("scroll", () => {
        const index = Math.round(gallery.scrollLeft / gallery.clientWidth);
        photoCount.textContent = `${index + 1} / ${residence.images.length}`;
      }, { passive: true });
    }

    const content = document.createElement("div");
    content.className = "card-content";
    const meta = document.createElement("span");
    meta.className = "card-meta";
    meta.textContent = "Bedworth Park · Student residence";
    const title = document.createElement("h3");
    const titleButton = document.createElement("button");
    titleButton.className = "residence-title-button";
    titleButton.type = "button";
    titleButton.dataset.openResidence = residence.name;
    titleButton.textContent = residence.name;
    title.append(titleButton);
    const facts = document.createElement("div");
    facts.className = "residence-facts";
    const address = document.createElement("p");
    address.innerHTML = '<span>ADDRESS</span>';
    address.append(document.createTextNode(residence.address || "Not provided"));
    const availability = document.createElement("p");
    const hasAvailability = residence.availableRooms !== null && residence.availableRooms !== undefined;
    availability.className = hasAvailability ? "availability-known" : "";
    availability.innerHTML = `<span>AVAILABILITY</span>${hasAvailability ? `Available — ${residence.availableRooms} rooms` : "Not provided"}`;
    facts.append(address, availability);
    const footer = document.createElement("div");
    footer.className = "residence-actions";
    const applyButton = document.createElement("button");
    applyButton.className = "residence-action residence-action-primary";
    applyButton.type = "button";
    applyButton.dataset.openApplication = "";
    applyButton.dataset.selectedResidence = residence.name;
    applyButton.textContent = "Apply";
    const spaceButton = document.createElement("button");
    spaceButton.className = "residence-action";
    spaceButton.type = "button";
    spaceButton.dataset.openResidence = residence.name;
    spaceButton.textContent = "View Space";
    const directions = document.createElement("button");
    directions.className = "residence-action";
    directions.textContent = "Directions";
    directions.type = "button";
    directions.dataset.getDirections = "";
    directions.dataset.destination = residence.address || residence.name;
    directions.dataset.destinationLabel = residence.name;
    directions.dataset.verifiedAddress = String(Boolean(residence.address));
    const rebookButton = document.createElement("button");
    rebookButton.className = "residence-action";
    rebookButton.type = "button";
    rebookButton.dataset.openApplication = "";
    rebookButton.dataset.selectedResidence = residence.name;
    rebookButton.textContent = "Apply again";
    footer.append(applyButton, spaceButton, directions, rebookButton);
    content.append(meta, title, facts, footer);
    card.append(imageWrap, content);
    return card;
  });
  const groupedCards = [];
  let previousUniversity = "";
  shown.forEach((residence, index) => {
    if (residence.university !== previousUniversity) {
      const university = universityDirectory[residence.university];
      const heading = document.createElement("div");
      heading.className = "university-directory-heading";
      const logo = document.createElement("img");
      logo.src = university.logo;
      logo.alt = `${university.name} logo`;
      logo.loading = "lazy";
      const copy = document.createElement("div");
      const title = document.createElement("h3");
      title.textContent = university.name;
      const description = document.createElement("p");
      const universityCount = shown.filter((item) => item.university === residence.university).length;
      description.textContent = `${university.shortName} residences · ${universityCount} shown on this page`;
      copy.append(title, description);
      heading.append(logo, copy);
      groupedCards.push(heading);
      previousUniversity = residence.university;
    }
    groupedCards.push(cards[index]);
  });
  grid.replaceChildren(...groupedCards);

  countLabel.textContent = matches.length
    ? `SHOWING ${start + 1}–${start + shown.length} OF ${matches.length} ${matches.length === 1 ? "RESIDENCE" : "RESIDENCES"}`
    : "0 RESIDENCES FOUND";
  emptyState.hidden = matches.length !== 0;
  pagination.replaceChildren();
  pagination.hidden = pageCount <= 1;
  if (pageCount <= 1) return;

  const addPageButton = (label, page, options = {}) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = options.arrow ? "pagination-arrow" : "pagination-number";
    button.textContent = label;
    button.disabled = options.disabled || false;
    button.setAttribute("aria-label", options.ariaLabel || `Page ${page}`);
    if (page === currentPage && !options.arrow) button.setAttribute("aria-current", "page");
    button.addEventListener("click", () => {
      currentPage = page;
      renderResidences();
    });
    pagination.append(button);
  };

  addPageButton("‹", currentPage - 1, {
    arrow: true,
    disabled: currentPage === 1,
    ariaLabel: "Previous page"
  });
  for (let page = 1; page <= pageCount; page += 1) {
    addPageButton(String(page), page);
  }
  addPageButton("›", currentPage + 1, {
    arrow: true,
    disabled: currentPage === pageCount,
    ariaLabel: "Next page"
  });
}

function setApplicationResidenceOptions(university = "") {
  const residenceSelect = applicationForm.elements.residence;
  const availableResidences = university
    ? residences.filter((residence) => residence.university === university)
    : residences;
  residenceSelect.replaceChildren(
    new Option("Choose a residence", ""),
    ...availableResidences.map((residence) => new Option(residence.name, residence.name))
  );
}

function showUniversityChoice(selectedResidence = "", startNew = false) {
  residenceToApplyFor = selectedResidence;
  residenceApplicationStartNew = startNew;
  universityChoiceDialog.showModal();
}

function setResidences(data) {
  const hasTenBellona = data.some((residence) => residence.name === "Bovua@10Bellona");
  residences = data
    .filter((residence) => (
      !removedResidenceNames.has(residence.name)
      && !(residence.name === "Bovua@2Bellona" && hasTenBellona)
    ))
    .map((residence) => ({
      name: residence.name === "Bovua@10Bellona" ? "Bovua@2Bellona" : residence.name,
      university: vutResidenceNames.has(residence.name) ? "vut" : "nwu",
      images: residence.name === "Bovua@2Bellona" || residence.name === "Bovua@10Bellona"
        ? tenBellonaResidenceImages
        : residence.name === "Bovua@36Aurora"
          ? [...new Set([...auroraResidenceImages, ...(Array.isArray(residence.images) ? residence.images : [])])]
          : residence.name === "Bovua@1Ganymade"
            ? [...new Set([...oneGanymadeResidenceImages, ...(Array.isArray(residence.images) ? residence.images : [])])]
            : Array.isArray(residence.images) ? residence.images : [],
      address: residence.address,
      availableRooms: residence.available_rooms ?? residence.availableRooms
    }));
  setApplicationResidenceOptions(selectedApplicationUniversity);
  renderResidences();
}

async function loadResidences() {
  if (!supabaseClient) {
    setResidences(fallbackResidences);
    setStatus(directoryStatus, `Showing the built-in directory of ${residences.length} residences. Live applications need Supabase configured.`, true);
    return;
  }

  let result;
  try {
    result = await supabaseClient
      .from("residences")
      .select("name, images, address, available_rooms")
      .order("name");
  } catch (error) {
    setResidences(fallbackResidences);
    setStatus(directoryStatus, `Showing the built-in directory of ${residences.length} residences. Could not load the live directory: ${error.message}`, true);
    return;
  }
  const { data, error } = result;
  if (error) {
    setResidences(fallbackResidences);
    setStatus(directoryStatus, `Showing the built-in directory of ${residences.length} residences. Could not load the live directory: ${error.message} Run supabase/setup.sql in the Supabase SQL Editor to enable applications.`, true);
    return;
  }
  if (!data || data.length === 0) {
    setResidences(fallbackResidences);
    setStatus(directoryStatus, `Showing the built-in directory of ${residences.length} residences. Run supabase/setup.sql in the Supabase SQL Editor to populate Supabase and enable applications.`, true);
    return;
  }

  setResidences(data);
  setStatus(directoryStatus, `Addresses and availability are shown only when supplied. ${residences.length} residences loaded from Supabase.`);
}

function isVerifiedUser(user = currentUser) {
  return Boolean(user && (user.email_confirmed_at || user.confirmed_at));
}

function setAuthView(view) {
  authView = view;
  registerForm.hidden = view !== "register";
  loginForm.hidden = view !== "login";
  recoveryForm.hidden = view !== "recovery";
  newPasswordForm.hidden = view !== "new-password";
  setStatus(authStatus, "");
  if (view === "register") document.querySelector("#register-name").focus();
  if (view === "login") document.querySelector("#login-email").focus();
}

function getAuthRedirectUrl(flow) {
  const redirect = new URL("/", window.location.origin);
  redirect.searchParams.set("auth", flow);
  return redirect.toString();
}

function getAuthErrorMessage(error, action = "create your account") {
  const code = String(error?.code || "").toLowerCase();
  const detail = String(error?.message || "").toLowerCase();
  const status = Number(error?.status || 0);

  if (code.includes("invalid_api_key") || /invalid api key|invalid authorization key/.test(detail)) {
    return "The site's Supabase configuration is incorrect. Please contact the website administrator.";
  }
  if (
    ["user_already_exists", "email_exists"].includes(code)
    || /already (?:been )?registered|already exists/.test(detail)
  ) {
    return "An account may already be registered with this email. Sign in or use password recovery instead.";
  }
  if (code === "weak_password" || (detail.includes("password") && /minimum|at least|characters|too short|weak/.test(detail))) {
    const passwordRequirement = String(error?.message || "").trim();
    if (/^password\b/i.test(passwordRequirement) && passwordRequirement.length <= 140 && !/[<>]/.test(passwordRequirement)) {
      return `Password requirement: ${passwordRequirement}`;
    }
    return "Your password does not meet the current requirements. Choose a stronger password and try again.";
  }
  if (/rate.?limit|too many requests|email.*limit|over_email_send_rate_limit/.test(`${code} ${detail}`) || status === 429) {
    return "Verification email requests are temporarily limited. Please wait a while before trying again.";
  }
  if (/email.*(?:send|deliver)|(?:send|deliver).*email|smtp|mail provider/.test(detail)) {
    if (action !== "create your account") {
      return "The verification email could not be sent. Check the address and try again later.";
    }
    return "The verification email could not be sent, so registration is not confirmed. Please try again later or contact support.";
  }
  if (/invalid email|email address.*invalid|unable to validate email/.test(detail)) {
    return "Enter a valid email address and try again.";
  }
  if (status === 401 || /invalid jwt|unauthorized/.test(`${code} ${detail}`)) {
    return "The site's Supabase configuration is incorrect. Please contact the website administrator.";
  }
  if (/fetch|network|failed to connect|load failed|timeout/.test(detail)) {
    return "We could not reach the account service. Check your connection and try again.";
  }
  return `We couldn’t ${action}. Please check your details and try again.`;
}

function getAuthCallbackError(url = new URL(window.location.href)) {
  const fragment = new URLSearchParams(url.hash.slice(1));
  return url.searchParams.get("error_description")
    || url.searchParams.get("error")
    || fragment.get("error_description")
    || fragment.get("error");
}

function cleanAuthCallbackUrl() {
  const cleanUrl = new URL(window.location.href);
  ["auth", "code", "error", "error_code", "error_description", "email"].forEach((key) => cleanUrl.searchParams.delete(key));
  cleanUrl.hash = "";
  window.history.replaceState({}, document.title, cleanUrl.toString());
}

function updateAuthenticationUI() {
  const verified = authReady && isVerifiedUser();
  const waitingForVerification = !verified && Boolean(currentUser || pendingVerificationEmail || verificationLinkError);
  const showingSubmissionSuccess = !applicationSuccessPanel.hidden;
  authForms.hidden = verified && !passwordRecoveryInProgress || waitingForVerification && !showAuthDuringVerification;
  verificationPanel.hidden = !waitingForVerification || showAuthDuringVerification;
  signedInPanel.hidden = !verified || passwordRecoveryInProgress;
  studentApplications.hidden = !verified || applicationFormOpen || showingSubmissionSuccess || passwordRecoveryInProgress;
  applicationForm.hidden = !verified || (!applicationFormOpen && !showingSubmissionSuccess) || passwordRecoveryInProgress;
  document.querySelector(".step-progress").hidden = !verified || !applicationFormOpen || passwordRecoveryInProgress;
  if (verified && !passwordRecoveryInProgress) {
    signedInEmail.textContent = currentUser.email || "Signed-in account";
    document.querySelector("#verification-email").textContent = "";
    document.querySelector("#verification-change-email").value = currentUser.email || "";
  } else if (waitingForVerification) {
    const email = currentUser?.email || pendingVerificationEmail;
    document.querySelector("#verification-email").textContent = email
      ? `We sent a verification link to ${email}. Verify your email before signing in to the application.`
      : "The verification link may be invalid or expired. Enter your registration email to request a new link.";
    document.querySelector("#verification-change-email").value = email || "";
  } else if (authReady && supabaseUnavailableMessage) {
    setStatus(authStatus, supabaseUnavailableMessage, true);
  }
}

async function loadStudentApplications() {
  if (!supabaseClient || !currentUser || !isVerifiedUser()) return [];
  setStatus(applicationListStatus, "Loading your applications…");
  let result;
  try {
    result = await supabaseClient
      .from("applications")
      .select("id, user_id, application_reference, status, first_name, surname, student_number, email, phone, residence_name, move_in_date, room_type, proof_of_registration_path, proof_of_funding_path, identity_document_path, created_at, submitted_at")
      .eq("user_id", currentUser.id)
      .order("created_at", { ascending: false });
  } catch {
    setStatus(applicationListStatus, "We couldn’t load your applications. Please try again later.", true);
    return null;
  }
  if (result.error) {
    setStatus(applicationListStatus, "We couldn’t load your applications. Please try again later.", true);
    return null;
  }
  const applications = result.data || [];
  applicationList.replaceChildren();
  for (const record of applications) {
    const item = document.createElement("article");
    item.className = "application-list-item";
    const summary = document.createElement("p");
    const reference = document.createElement("strong");
    reference.textContent = record.application_reference || "Application";
    const residence = residences.find((item) => item.name === record.residence_name);
    const status = ({
      submitted: "Pending management approval",
      under_review: "Under management review",
      approved: "Approved",
      rejected: "Not approved",
      draft: "Draft"
    })[record.status] || String(record.status).replaceAll("_", " ");
    const date = record.status === "draft" ? record.created_at : record.submitted_at || record.created_at;
    const dateLabel = record.status === "draft" ? "Draft started" : "Submitted";
    const formattedDate = date
      ? new Intl.DateTimeFormat(undefined, { dateStyle: "medium" }).format(new Date(date))
      : "";
    const details = document.createElement("span");
    details.textContent = `${residence?.name || record.residence_name || "Residence not selected"} · ${status}${formattedDate ? ` · ${dateLabel} ${formattedDate}` : ""}`;
    summary.append(reference, details);
    const actions = document.createElement("div");
    actions.className = "auth-links";
    const action = document.createElement("button");
    action.className = "button button-outline";
    action.type = "button";
    action.textContent = record.status === "draft" ? "Resume draft" : "View documents";
    action.addEventListener("click", () => record.status === "draft" ? resumeApplication(record) : showApplicationDocuments(record));
    actions.append(action);
    item.append(summary, actions);
    applicationList.append(item);
  }
  setStatus(applicationListStatus, applications.length ? "" : "You don’t have any applications yet.");
  return applications;
}

async function showApplicationDocuments(record) {
  if (!await verifyCurrentStudent()) return;
  const links = [];
  for (const documentField of documentFields) {
    const path = record[documentField.column];
    if (!path) continue;
    let result;
    try {
      result = await supabaseClient.storage.from("application-documents").createSignedUrl(path, 60);
    } catch {
      setStatus(applicationListStatus, "We couldn’t open your private documents. Please try again later.", true);
      return;
    }
    if (result.error) {
      setStatus(applicationListStatus, "We couldn’t open your private documents. Please try again later.", true);
      return;
    }
    links.push({ label: documentField.label, url: result.data.signedUrl });
  }
  applicationList.replaceChildren();
  for (const link of links) {
    const anchor = document.createElement("a");
    anchor.className = "button button-outline";
    anchor.href = link.url;
    anchor.target = "_blank";
    anchor.rel = "noopener noreferrer";
    anchor.textContent = `Open ${link.label}`;
    applicationList.append(anchor);
  }
  setStatus(applicationListStatus, links.length ? "" : "No documents are attached to this application.");
}

async function handleAuthState(session, event = "") {
  currentSession = session;
  currentUser = session?.user || null;
  authReady = true;
  if (event === "PASSWORD_RECOVERY") {
    passwordRecoveryInProgress = true;
    applicationFormOpen = false;
    setAuthView("new-password");
    applicationDialog.showModal();
  }
  if (currentUser && !isVerifiedUser()) pendingVerificationEmail = currentUser.email || pendingVerificationEmail;
  if (isVerifiedUser()) pendingVerificationEmail = "";
  if (isVerifiedUser()) {
    verificationLinkError = false;
    showAuthDuringVerification = false;
  }
  updateAuthenticationUI();

  if (!currentUser) {
    if (openMyApplications) {
      openMyApplications = false;
      applicationDialog.showModal();
    }
    if (autoOpenApplication && !window.location.hash.includes("access_token")) {
      const error = new URLSearchParams(window.location.hash.slice(1)).get("error_description")
        || new URLSearchParams(window.location.search).get("error_description");
      if (error) {
        pendingVerificationEmail = new URLSearchParams(window.location.search).get("email") || "";
        verificationLinkError = true;
        setStatus(authStatus, "This verification link is invalid or expired. Enter your email below to request a new verification link.", true);
        updateAuthenticationUI();
      }
    }
    return;
  }
  if (!isVerifiedUser()) {
    if (openMyApplications) {
      openMyApplications = false;
      applicationDialog.showModal();
    }
    return;
  }

  const applications = await loadStudentApplications();
  if (!applications) {
    if (openMyApplications) {
      openMyApplications = false;
      applicationDialog.showModal();
    }
    if (autoOpenApplication) {
      autoOpenApplication = false;
      applicationDialog.showModal();
    }
    return;
  }
  if (openMyApplications) {
    openMyApplications = false;
    applicationFormOpen = false;
    updateAuthenticationUI();
    applicationDialog.showModal();
    return;
  }
  if (autoOpenApplication && isVerifiedUser()) {
    autoOpenApplication = false;
    const draft = applications.find((application) => application.status === "draft");
    if (draft) {
      resumeApplication(draft);
      applicationDialog.showModal();
    } else if (applications.length) {
      const existing = applications[0];
      const reference = existing.application_reference || "your existing application";
      setStatus(applicationListStatus, `${reference} is already on file. Review its status below; start another application only if you need to.`);
      applicationDialog.showModal();
    } else {
      showApplicationForm();
    }
  }
}

async function initializeAuthentication() {
  const callbackUrl = new URL(window.location.href);
  const params = callbackUrl.searchParams;
  const isVerificationCallback = params.get("auth") === "verify";
  let verificationCallbackExchanged = false;
  autoOpenApplication = false;
  openMyApplications = params.get("applications") === "1";
  if (params.get("auth") === "recovery") {
    passwordRecoveryInProgress = true;
    setAuthView("new-password");
  }
  if (!supabaseClient) {
    authReady = true;
    updateAuthenticationUI();
    if (params.get("auth") === "verify" || params.get("auth") === "recovery" || openMyApplications) {
      openMyApplications = false;
      applicationDialog.showModal();
    }
    return;
  }
  supabaseClient.auth.onAuthStateChange((event, session) => {
    window.setTimeout(() => { handleAuthState(session, event); }, 0);
  });

  let result;
  try {
    const callbackError = getAuthCallbackError(callbackUrl);
    if (callbackError) {
      if (params.get("auth") === "verify") {
        verificationLinkError = true;
        pendingVerificationEmail = params.get("email") || "";
        setStatus(authStatus, "This verification link is invalid or expired. Request a new verification email, then try again.", true);
        updateAuthenticationUI();
      } else if (params.get("auth") === "recovery") {
        passwordRecoveryInProgress = false;
        setAuthView("recovery");
        setStatus(authStatus, "This password reset link is invalid or expired. Request a new reset email and try again.", true);
      }
      cleanAuthCallbackUrl();
      result = await supabaseClient.auth.getSession();
    } else if (params.get("code")) {
      setStatus(authStatus, "Confirming your email securely…");
      result = await supabaseClient.auth.exchangeCodeForSession(params.get("code"));
      if (result.error) {
        if (params.get("auth") === "verify") {
          verificationLinkError = true;
          pendingVerificationEmail = params.get("email") || "";
          setStatus(authStatus, "This verification link is invalid or expired. Request a new verification email, then try again.", true);
          updateAuthenticationUI();
        } else if (params.get("auth") === "recovery") {
          passwordRecoveryInProgress = false;
          setAuthView("recovery");
          setStatus(authStatus, "This password reset link is invalid or expired. Request a new reset email and try again.", true);
        }
      } else {
        currentSession = result.data.session;
        if (isVerificationCallback) verificationCallbackExchanged = true;
      }
      cleanAuthCallbackUrl();
      if (result.error) result = await supabaseClient.auth.getSession();
    } else {
      const fragment = new URLSearchParams(callbackUrl.hash.slice(1));
      const accessToken = fragment.get("access_token");
      const refreshToken = fragment.get("refresh_token");
      if (accessToken && refreshToken) {
        setStatus(authStatus, "Confirming your email securely…");
        result = await supabaseClient.auth.setSession({
          access_token: accessToken,
          refresh_token: refreshToken
        });
        if (!result.error && isVerificationCallback) verificationCallbackExchanged = true;
        if (result.error && params.get("auth") === "verify") {
          verificationLinkError = true;
          setStatus(authStatus, "This verification link is invalid or expired. Request a new verification email, then try again.", true);
          updateAuthenticationUI();
        }
        cleanAuthCallbackUrl();
        if (result.error) result = await supabaseClient.auth.getSession();
      } else {
        if (params.get("auth") === "verify") {
          verificationLinkError = true;
          pendingVerificationEmail = params.get("email") || "";
          setStatus(authStatus, "The verification link is incomplete or expired. Request a new verification email and try again.", true);
          updateAuthenticationUI();
        } else if (params.get("auth") === "recovery") {
          passwordRecoveryInProgress = false;
          setAuthView("recovery");
          setStatus(authStatus, "This password reset link is incomplete or expired. Request a new reset email and try again.", true);
        }
        result = await supabaseClient.auth.getSession();
      }
    }
  } catch {
    authReady = true;
    updateAuthenticationUI();
    if (params.get("auth") === "verify") {
      verificationLinkError = true;
      setStatus(authStatus, "We couldn’t confirm your email. Check your connection or request a new verification link.", true);
      updateAuthenticationUI();
    } else {
      setStatus(authStatus, "We couldn’t check your sign-in. Please reload the page and try again.", true);
    }
    if (params.get("auth") === "verify" || params.get("auth") === "recovery") applicationDialog.showModal();
    return;
  }
  if (result.error) {
    authReady = true;
    updateAuthenticationUI();
    setStatus(authStatus, "We couldn’t check your sign-in. Please reload the page and try again.", true);
    if (params.get("auth") === "verify" || params.get("auth") === "recovery") applicationDialog.showModal();
    return;
  }
  if (isVerificationCallback) {
    if (verificationCallbackExchanged && isVerifiedUser(result.data.session?.user)) {
      autoOpenApplication = true;
    } else if (!verificationLinkError) {
      verificationLinkError = true;
      setStatus(authStatus, "Supabase didn’t confirm this email. Request a new verification link and try again.", true);
      updateAuthenticationUI();
    }
  }
  await handleAuthState(result.data.session, result.data.session ? "INITIAL_SESSION" : "");
  if (params.get("auth") === "recovery" && !result.data.session && !passwordRecoveryInProgress) {
    setStatus(authStatus, "This password reset link is invalid or expired. Request a new reset email.", true);
    setAuthView("recovery");
  }
  if ((isVerificationCallback && verificationLinkError) || params.get("auth") === "recovery") {
    if (!applicationDialog.open) applicationDialog.showModal();
  }
}

function escapeHtml(value) {
  return value.replace(/[&<>"']/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[character]);
}

function requestCurrentLocation() {
  const requestId = ++locationRequestId;
  directionsStatus.textContent = "Finding your current location…";
  directionsLink.hidden = true;
  retryLocationButton.hidden = true;
  retryLocationButton.disabled = true;
  locationHelp.hidden = true;

  if (!navigator.geolocation) {
    directionsStatus.textContent = "Your browser doesn’t support live location. Open this page in a browser with location services enabled.";
    locationHelp.hidden = window.isSecureContext;
    retryLocationButton.hidden = false;
    retryLocationButton.disabled = false;
    return;
  }

  navigator.geolocation.getCurrentPosition((position) => {
    if (requestId !== locationRequestId) return;
    const origin = `${position.coords.latitude},${position.coords.longitude}`;
    const destination = /\bsouth africa\b/i.test(directionsDestination)
      ? directionsDestination
      : /\bbedworth park\b/i.test(directionsDestination)
        ? `${directionsDestination}, South Africa`
        : `${directionsDestination}, Bedworth Park, South Africa`;
    const query = new URLSearchParams({ api: "1", origin, destination });
    directionsLink.href = `https://www.google.com/maps/dir/?${query.toString()}`;
    directionsStatus.textContent = `Your location is ready. Open the route to ${directionsDestinationLabel} in Google Maps.`;
    directionsLink.hidden = false;
    retryLocationButton.hidden = false;
    retryLocationButton.disabled = false;
  }, (error) => {
    if (requestId !== locationRequestId) return;
    const messages = {
      1: "Location access was denied. Allow location permission in your browser settings, then try again.",
      2: "Your device couldn’t determine your location. Check that location services are on, then try again.",
      3: "Location lookup took too long. Check your connection and try again."
    };
    directionsStatus.textContent = messages[error.code] || "We couldn’t get your location. Check your browser permissions and try again.";
    locationHelp.hidden = window.isSecureContext;
    retryLocationButton.hidden = false;
    retryLocationButton.disabled = false;
  }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 30000 });
}

function openDirections(destination, label, hasVerifiedAddress = false) {
  if (detailsDialog.open) detailsDialog.close();
  directionsDestination = destination;
  directionsDestinationLabel = label;
  directionsAddressNote.hidden = hasVerifiedAddress || label === "Bedworth Park";
  directionsDialog.showModal();
  requestCurrentLocation();
}

let activeResidencePhotos = [];
let activeResidencePhotoIndex = 0;
let activeResidencePhotoLoadId = 0;

function setResidencePhoto(index) {
  if (!activeResidencePhotos.length) return;
  activeResidencePhotoIndex = (index + activeResidencePhotos.length) % activeResidencePhotos.length;
  const frame = detailsContent.querySelector(".details-photo-frame");
  const image = frame.querySelector(".details-main-photo");
  const counter = detailsContent.querySelector(".gallery-count");
  const thumbnails = detailsContent.querySelectorAll(".details-thumbnail");
  const source = activeResidencePhotos[activeResidencePhotoIndex];
  const loadId = ++activeResidencePhotoLoadId;

  frame.classList.remove("has-error");
  frame.classList.add("is-loading");
  frame.setAttribute("aria-busy", "true");
  frame.querySelector(".photo-loading").hidden = false;
  frame.querySelector(".photo-fallback").hidden = true;
  image.hidden = false;
  image.alt = `${detailsContent.dataset.residenceName} ${detailsContent.dataset.photoCategory || "photo"} ${activeResidencePhotoIndex + 1}`;
  image.onload = () => {
    if (loadId !== activeResidencePhotoLoadId) return;
    frame.classList.remove("is-loading", "has-error");
    frame.setAttribute("aria-busy", "false");
    frame.querySelector(".photo-loading").hidden = true;
  };
  image.onerror = () => {
    if (loadId !== activeResidencePhotoLoadId) return;
    frame.classList.remove("is-loading");
    frame.classList.add("has-error");
    frame.setAttribute("aria-busy", "false");
    frame.querySelector(".photo-loading").hidden = true;
    frame.querySelector(".photo-fallback").hidden = false;
    image.hidden = true;
  };
  image.src = source;
  counter.textContent = `${activeResidencePhotoIndex + 1} of ${activeResidencePhotos.length}`;
  thumbnails.forEach((thumbnail, thumbnailIndex) => {
    thumbnail.setAttribute("aria-pressed", String(thumbnailIndex === activeResidencePhotoIndex));
  });
  thumbnails[activeResidencePhotoIndex]?.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "smooth" });
}

function renderResidencePhotos(photos, emptyMessage = "No photos are available for this residence.", initialPhoto = 0) {
  activeResidencePhotos = photos;
  activeResidencePhotoIndex = Math.max(0, Math.min(initialPhoto, photos.length - 1));
  activeResidencePhotoLoadId += 1;

  const frame = detailsContent.querySelector(".details-photo-frame");
  const image = frame.querySelector(".details-main-photo");
  const counter = detailsContent.querySelector(".gallery-count");
  const loading = frame.querySelector(".photo-loading");
  const fallback = frame.querySelector(".photo-fallback");
  const previous = frame.querySelector(".gallery-previous");
  const next = frame.querySelector(".gallery-next");
  const fullscreen = frame.querySelector(".gallery-fullscreen");
  const thumbnails = detailsContent.querySelector(".details-thumbnails");

  thumbnails.replaceChildren(...photos.map((source, index) => {
    const button = document.createElement("button");
    button.className = "details-thumbnail";
    button.type = "button";
    button.setAttribute("aria-label", `View photo ${index + 1} of ${photos.length}`);
    button.setAttribute("aria-pressed", "false");
    button.addEventListener("click", () => setResidencePhoto(index));
    const thumbnail = document.createElement("img");
    thumbnail.src = source;
    thumbnail.alt = "";
    thumbnail.loading = "lazy";
    button.append(thumbnail);
    return button;
  }));

  previous.hidden = photos.length < 2;
  next.hidden = photos.length < 2;
  fullscreen.hidden = photos.length === 0;
  if (!photos.length) {
    frame.classList.remove("is-loading");
    frame.classList.add("has-error");
    frame.setAttribute("aria-busy", "false");
    image.hidden = true;
    image.onload = null;
    image.onerror = null;
    loading.hidden = true;
    fallback.textContent = emptyMessage;
    fallback.hidden = false;
    counter.textContent = "No photos available";
    return;
  }

  fallback.hidden = true;
  counter.textContent = `${activeResidencePhotoIndex + 1} of ${photos.length}`;
  setResidencePhoto(activeResidencePhotoIndex);
}

function openResidence(name, initialPhoto = 0) {
  const residence = residences.find((item) => item.name === name);
  if (!residence) return;
  const addressText = residence.address || "Not provided";
  const availabilityText = residence.availableRooms !== null && residence.availableRooms !== undefined
    ? `Available — ${residence.availableRooms} rooms`
    : "Not provided";
  const isGanymade = residence.name === "Bovua@1Ganymade";
  const additionalGanymadePhotos = isGanymade
    ? residence.images.filter((source) => !oneGanymadeResidenceImages.includes(source))
    : [];
  const photoCategories = isGanymade
    ? oneGanymadePhotoCategories.map((category) => ({
      ...category,
      images: category.name === "Overview" ? [...category.images, ...additionalGanymadePhotos] : category.images
    }))
    : residence.name === "Bovua@2Bellona"
      ? tenBellonaPhotoCategories.map((category) => ({
        ...category,
        images: category.name === "Overview"
          ? [...category.images, ...residence.images.filter((source) => !tenBellonaResidenceImages.includes(source))]
          : category.images
      }))
      : [
      { name: "Overview", images: residence.images },
      { name: "Bedroom", images: [] },
      { name: "Kitchen", images: [] },
      { name: "Bathroom", images: [] },
      { name: "Study Area", images: [] },
      { name: "Facilities", images: [] }
    ];
  const initialCategory = photoCategories[0];
  activeResidencePhotos = initialCategory ? initialCategory.images : residence.images;
  detailsContent.dataset.residenceName = residence.name;
  detailsContent.dataset.photoCategory = initialCategory?.name || "photo";
  const categoryTabsHtml = `
    <nav class="room-category-tabs" role="tablist" aria-label="Residence photo categories">
      ${photoCategories.map((category, index) => `
        <button class="room-category-tab" id="details-category-${index}" type="button" role="tab" aria-selected="${String(index === 0)}" aria-controls="details-photo-frame" tabindex="${index === 0 ? "0" : "-1"}" data-category-index="${index}">
          ${escapeHtml(category.name)}
        </button>
      `).join("")}
    </nav>
  `;
  detailsContent.innerHTML = `
    <div class="details-photo-tour">
      <div class="details-photo-frame ${activeResidencePhotos.length ? "is-loading" : "has-error"}" id="details-photo-frame" role="tabpanel" aria-labelledby="details-category-0" aria-busy="${String(Boolean(activeResidencePhotos.length))}">
        <img class="details-main-photo" alt="${escapeHtml(residence.name)} photo 1" ${activeResidencePhotos.length ? "" : "hidden"}>
        <span class="photo-loading" role="status" ${activeResidencePhotos.length ? "" : "hidden"}>Loading photo…</span>
        <span class="photo-fallback" role="status" ${activeResidencePhotos.length ? "hidden" : ""}>${activeResidencePhotos.length ? "This photo could not be loaded." : "No photos are available for this residence."}</span>
        <button class="gallery-control gallery-previous" type="button" aria-label="Previous photo" ${activeResidencePhotos.length > 1 ? "" : "hidden"}>‹</button>
        <span class="gallery-count" aria-live="polite">${activeResidencePhotos.length ? `1 of ${activeResidencePhotos.length}` : "No photos available"}</span>
        <button class="gallery-control gallery-next" type="button" aria-label="Next photo" ${activeResidencePhotos.length > 1 ? "" : "hidden"}>›</button>
        <button class="gallery-fullscreen" type="button" aria-label="View photo full screen" title="View photo full screen" ${activeResidencePhotos.length ? "" : "hidden"}>
          <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8 3H3v5M16 3h5v5M3 16v5h5m13-5v5h-5"></path></svg>
        </button>
      </div>
      ${categoryTabsHtml}
      <div class="details-thumbnails" aria-label="Choose a residence photo"></div>
    </div>
    <div class="details-body">
      <p class="eyebrow"><span></span> STUDENT RESIDENCE · DETAILS</p>
      <h2 id="details-title">${escapeHtml(residence.name)}</h2>
      <div class="details-facts">
        <p><span>ADDRESS</span><strong>${escapeHtml(addressText)}</strong></p>
        <p><span>AVAILABILITY</span><strong>${escapeHtml(availabilityText)}</strong></p>
      </div>
      <p>${isGanymade
        ? "Browse the available room and facility photos above. Verified address, availability and pricing details have not been provided; please confirm them with management."
        : "Room types, facilities and pricing have not been provided. Please confirm residence information with management."}</p>
      ${isGanymade ? '<p class="virtual-tour-notice">360° virtual tour is not available yet. This gallery contains still photographs only.</p>' : ""}
      <div class="details-actions">
        <button class="button button-outline" type="button" data-get-directions data-destination="${escapeHtml(residence.address || residence.name)}" data-destination-label="${escapeHtml(residence.name)}" data-verified-address="${String(Boolean(residence.address))}">Directions from my location <span aria-hidden="true">↗</span></button>
        <button class="button button-dark apply-residence-button" type="button" data-open-application data-selected-residence="${escapeHtml(residence.name)}">Apply for This Residence <span aria-hidden="true">↗</span></button>
      </div>
    </div>`;

  const photoFrame = detailsContent.querySelector(".details-photo-frame");
  detailsContent.querySelector(".gallery-previous")?.addEventListener("click", () => {
    setResidencePhoto(activeResidencePhotoIndex - 1);
  });
  detailsContent.querySelector(".gallery-next")?.addEventListener("click", () => {
    setResidencePhoto(activeResidencePhotoIndex + 1);
  });
  detailsContent.querySelectorAll(".room-category-tab").forEach((tab) => {
    tab.addEventListener("click", () => {
      const categoryIndex = Number(tab.dataset.categoryIndex);
      const category = photoCategories[categoryIndex];
      detailsContent.querySelectorAll(".room-category-tab").forEach((item, index) => {
        item.setAttribute("aria-selected", String(index === categoryIndex));
        item.tabIndex = index === categoryIndex ? 0 : -1;
      });
      detailsContent.dataset.photoCategory = category.name;
      photoFrame.setAttribute("aria-labelledby", tab.id);
      const emptyMessage = category.name === "Bathroom" && (isGanymade || residence.name === "Bovua@2Bellona")
        ? `No dedicated bathroom photos have been provided for ${residence.name}.`
        : `No ${category.name.toLowerCase()} photos have been categorized for this residence yet. Browse Overview for available photos.`;
      renderResidencePhotos(category.images, emptyMessage);
    });
    tab.addEventListener("keydown", (event) => {
      const tabs = [...detailsContent.querySelectorAll(".room-category-tab")];
      const currentIndex = tabs.indexOf(tab);
      const nextIndex = event.key === "ArrowRight"
        ? (currentIndex + 1) % tabs.length
        : event.key === "ArrowLeft"
          ? (currentIndex - 1 + tabs.length) % tabs.length
          : event.key === "Home"
            ? 0
            : event.key === "End"
              ? tabs.length - 1
              : -1;
      if (nextIndex < 0) return;
      event.preventDefault();
      tabs[nextIndex].focus();
      tabs[nextIndex].click();
    });
  });
  detailsContent.querySelector(".gallery-fullscreen").addEventListener("click", async () => {
    const status = photoFrame.querySelector(".photo-fallback");
    try {
      if (document.fullscreenElement) {
        await document.exitFullscreen();
      } else if (photoFrame.requestFullscreen) {
        await photoFrame.requestFullscreen();
      } else {
        status.hidden = false;
        status.textContent = "Full-screen viewing is not supported by this browser.";
      }
    } catch (error) {
      status.hidden = false;
      status.textContent = "Could not open full-screen viewing. Please try again.";
      console.error("Could not change photo viewing mode.", error);
    }
  });

  activeResidencePhotoIndex = Math.max(0, Math.min(initialPhoto, activeResidencePhotos.length - 1));
  detailsDialog.showModal();
  renderResidencePhotos(activeResidencePhotos, undefined, isGanymade ? 0 : initialPhoto);
}

detailsDialog.addEventListener("keydown", (event) => {
  if (!detailsDialog.open || !activeResidencePhotos.length || event.target.closest(".room-category-tab")) return;
  if (event.key === "ArrowLeft") {
    event.preventDefault();
    setResidencePhoto(activeResidencePhotoIndex - 1);
  }
  if (event.key === "ArrowRight") {
    event.preventDefault();
    setResidencePhoto(activeResidencePhotoIndex + 1);
  }
});

document.addEventListener("fullscreenchange", () => {
  const fullscreenButton = detailsContent.querySelector(".gallery-fullscreen");
  if (!fullscreenButton) return;
  const isFullscreen = document.fullscreenElement === detailsContent.querySelector(".details-photo-frame");
  const label = isFullscreen ? "Exit full screen" : "View photo full screen";
  fullscreenButton.setAttribute("aria-label", label);
  fullscreenButton.title = label;
});

function setApplicationStep(step) {
  document.querySelectorAll(".form-step").forEach((section) => {
    const isActive = Number(section.dataset.step) === step;
    section.hidden = !isActive;
    section.classList.toggle("active", isActive);
  });
  document.querySelectorAll(".progress-item").forEach((item, index) => item.classList.toggle("active", index < step));
  if (step === 3) updateReview();
}

function updateReview() {
  const values = new FormData(applicationForm);
  const selectedResidence = residences.find((residence) => residence.name === values.get("residence"));
  const rows = [
    ["Name", `${values.get("firstName")} ${values.get("surname")}`],
    ["Student number", values.get("studentNumber")],
    ["Email", values.get("email")],
    ["Contact number", values.get("phone")],
    ["Preferred residence", selectedResidence ? selectedResidence.name : "Not selected"],
    ["Move-in date", values.get("moveIn") || "Not provided"],
    ["Room preference", values.get("roomType") || "Not specified"],
    ...documentFields.map((item) => {
      const file = values.get(item.input);
      return [item.label, file?.name || (applicationRecord?.[item.column] ? "Previously uploaded" : "Not uploaded")];
    })
  ];
  document.querySelector("#review-summary").replaceChildren(...rows.map(([label, value]) => {
    const paragraph = document.createElement("p");
    const strong = document.createElement("strong");
    paragraph.append(document.createTextNode(`${label}:`), strong);
    strong.textContent = value;
    return paragraph;
  }));
}

function updateEvidenceCard(application) {
  const values = new FormData(applicationForm);
  const setEvidenceValue = (id, value) => {
    document.querySelector(`#${id}`).textContent = value;
  };
  const moveIn = values.get("moveIn");
  const firstName = values.get("firstName");
  const surname = values.get("surname");
  setEvidenceValue("evidence-first-name", firstName);
  setEvidenceValue("evidence-surname", surname);
  setEvidenceValue("evidence-name", `${firstName} ${surname}`);
  setEvidenceValue("evidence-student-number", values.get("studentNumber"));
  setEvidenceValue("evidence-phone", values.get("phone"));
  setEvidenceValue("evidence-email", values.get("email"));
  setEvidenceValue("evidence-residence", values.get("residence"));
  setEvidenceValue("evidence-room-type", values.get("roomType") || "Not specified");
  setEvidenceValue("evidence-move-in", moveIn || "Not provided");
  const submittedAt = new Date(application.submitted_at || application.created_at);
  const generatedAt = new Date();
  setEvidenceValue("evidence-reference", application.application_reference || application.id);
  setEvidenceValue("evidence-submission-date", new Intl.DateTimeFormat(undefined, {
    dateStyle: "medium",
    timeStyle: "short"
  }).format(submittedAt));
  const generatedTime = document.querySelector("#evidence-generated");
  generatedTime.dateTime = generatedAt.toISOString();
  generatedTime.textContent = new Intl.DateTimeFormat(undefined, {
    dateStyle: "medium",
    timeStyle: "short"
  }).format(generatedAt);
}

async function openApplication(selectedResidence = "", startNew = false, university = "") {
  applicationSuccessPanel.hidden = true;
  if (!university) {
    showUniversityChoice(selectedResidence);
    return;
  }
  selectedApplicationUniversity = university;
  setApplicationResidenceOptions(university);
  if (!residences.some((residence) => (
    residence.name === selectedResidence && residence.university === university
  ))) selectedResidence = "";

  await authenticationInitialization;
  if (!isVerifiedUser()) {
    pendingApplicationAfterSignIn = true;
    pendingApplicationResidence = selectedResidence;
    pendingApplicationUniversity = university;
    pendingApplicationStartNew = startNew;
    showAuthDuringVerification = true;
    applicationFormOpen = false;
    setAuthView("login");
    updateAuthenticationUI();
    document.querySelector("#login-email").focus();
    applicationDialog.showModal();
    return;
  }
  if (!await verifyCurrentStudent()) {
    currentUser = null;
    currentSession = null;
    pendingApplicationAfterSignIn = true;
    pendingApplicationResidence = selectedResidence;
    pendingApplicationUniversity = university;
    pendingApplicationStartNew = startNew;
    showAuthDuringVerification = true;
    applicationFormOpen = false;
    setAuthView("login");
    updateAuthenticationUI();
    document.querySelector("#login-email").focus();
    setStatus(authStatus, "Your sign-in session couldn’t be verified. Please sign in again before applying.", true);
    if (!applicationDialog.open) applicationDialog.showModal();
    return;
  }

  const applications = await loadStudentApplications();
  if (!applications) {
    applicationFormOpen = false;
    updateAuthenticationUI();
    applicationDialog.showModal();
    return;
  }
  const universityApplications = applications.filter((application) => (
    residences.some((residence) => (
      residence.name === application.residence_name && residence.university === university
    ))
  ));
  if (!startNew) {
    const draft = universityApplications.find((application) => application.status === "draft");
    if (draft) {
      await resumeApplication(draft);
      applicationDialog.showModal();
      return;
    }
    if (universityApplications.length) {
      applicationFormOpen = false;
      updateAuthenticationUI();
      const existing = universityApplications[0];
      const reference = existing.application_reference || "your existing application";
      setStatus(applicationListStatus, `${reference} is already on file. Review its status below; start another application only if you need to.`);
      applicationDialog.showModal();
      return;
    }
  }
  showApplicationForm(selectedResidence);
}

function showApplicationForm(selectedResidence = "") {
  applicationRecord = null;
  applicationFormOpen = true;
  applicationForm.reset();
  setApplicationResidenceOptions(selectedApplicationUniversity);
  updateDocumentRequirements();
  applicationForm.elements.email.value = currentUser.email || "";
  const fullName = String(currentUser.user_metadata?.full_name || "").trim().split(/\s+/);
  applicationForm.elements.firstName.value = fullName.shift() || "";
  applicationForm.elements.surname.value = fullName.join(" ");
  setStatus(applicationStatus, "");
  applicationForm.elements.residence.value = residences.some((residence) => residence.name === selectedResidence)
    ? selectedResidence
    : "";
  applicationForm.querySelectorAll(".form-step").forEach((section) => { section.hidden = false; });
  applicationForm.querySelector('[data-step="2"]').hidden = true;
  applicationForm.querySelector('[data-step="3"]').hidden = true;
  document.querySelector("#preview-complete").hidden = true;
  applicationForm.querySelectorAll(".form-step input, .form-step select, .form-step button").forEach((element) => { element.disabled = false; });
  document.querySelector("#preview-complete").hidden = true;
  setApplicationStep(1);
  updateAuthenticationUI();
  if (!applicationDialog.open) applicationDialog.showModal();
}

async function verifyCurrentStudent() {
  if (!supabaseClient || !currentUser || !isVerifiedUser()) {
    setStatus(applicationStatus, "Verify your student email and sign in before continuing.", true);
    return false;
  }
  let result;
  try {
    result = await supabaseClient.auth.getUser();
  } catch {
    setStatus(applicationStatus, "We couldn’t verify your session. Please sign in again.", true);
    return false;
  }
  if (result.error || !result.data.user || result.data.user.id !== currentUser.id || !isVerifiedUser(result.data.user)) {
    setStatus(applicationStatus, "Your verified session has expired. Sign in again to continue.", true);
    return false;
  }
  currentUser = result.data.user;
  return true;
}

async function validateDocumentFile(file, label) {
  if (!file || file.size <= 0 || file.size > maximumDocumentSize) {
    setStatus(applicationStatus, `${label} must be a non-empty file no larger than 10 MB.`, true);
    return false;
  }
  if (!allowedDocumentTypes.has(file.type)) {
    setStatus(applicationStatus, `${label} must be a PDF, JPG or PNG file.`, true);
    return false;
  }
  const bytes = new Uint8Array(await file.slice(0, 8).arrayBuffer());
  const validSignature = file.type === "application/pdf"
    ? String.fromCharCode(...bytes.slice(0, 5)) === "%PDF-"
    : file.type === "image/jpeg"
      ? bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff
      : bytes.length >= 8 && bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47 && bytes[4] === 0x0d && bytes[5] === 0x0a && bytes[6] === 0x1a && bytes[7] === 0x0a;
  if (!validSignature) {
    setStatus(applicationStatus, `${label} does not appear to be a valid PDF, JPG or PNG file.`, true);
    return false;
  }
  return true;
}

function updateDocumentRequirements() {
  for (const item of documentFields) {
    applicationForm.elements[item.input].required = !applicationRecord?.[item.column];
  }
}

async function createDraftIfNeeded() {
  if (applicationRecord) return true;
  let result;
  try {
    result = await supabaseClient
      .from("applications")
      .insert({ user_id: currentUser.id, status: "draft" })
      .select("id, application_reference, status, proof_of_registration_path, proof_of_funding_path, identity_document_path")
      .single();
  } catch {
    setStatus(applicationStatus, "We couldn’t save your draft. Please try again.", true);
    return false;
  }
  if (result.error) {
    setStatus(applicationStatus, "We couldn’t save your draft. Please try again.", true);
    return false;
  }
  applicationRecord = result.data;
  return true;
}

async function saveApplicationDraft() {
  if (!await verifyCurrentStudent() || !await createDraftIfNeeded()) return false;
  const values = new FormData(applicationForm);
  const update = {
    first_name: String(values.get("firstName") || "").trim() || null,
    surname: String(values.get("surname") || "").trim() || null,
    student_number: String(values.get("studentNumber") || "").trim() || null,
    email: currentUser.email,
    phone: String(values.get("phone") || "").trim() || null,
    residence_name: values.get("residence") || null,
    move_in_date: values.get("moveIn") || null,
    room_type: values.get("roomType") || null
  };
  const uploadedPaths = [];
  for (const item of documentFields) {
    const file = values.get(item.input);
    if (!(file instanceof File) || !file.size) continue;
    if (!await validateDocumentFile(file, item.label)) {
      if (uploadedPaths.length) await supabaseClient.storage.from("application-documents").remove(uploadedPaths);
      return false;
    }
    const extension = file.type === "application/pdf" ? "pdf" : file.type === "image/jpeg" ? "jpg" : "png";
    const path = `${currentUser.id}/${applicationRecord.id}/${item.input}-${crypto.randomUUID()}.${extension}`;
    let upload;
    try {
      upload = await supabaseClient.storage.from("application-documents").upload(path, file, {
        contentType: file.type,
        upsert: false
      });
    } catch {
      if (uploadedPaths.length) await supabaseClient.storage.from("application-documents").remove(uploadedPaths);
      setStatus(applicationStatus, `We couldn’t securely upload ${item.label}. Please try again.`, true);
      return false;
    }
    if (upload.error) {
      if (uploadedPaths.length) await supabaseClient.storage.from("application-documents").remove(uploadedPaths);
      setStatus(applicationStatus, `We couldn’t securely upload ${item.label}. Please try again.`, true);
      return false;
    }
    uploadedPaths.push(path);
    update[item.column] = path;
  }

  let result;
  try {
    result = await supabaseClient
      .from("applications")
      .update(update)
      .eq("id", applicationRecord.id)
      .eq("user_id", currentUser.id)
      .eq("status", "draft")
      .select("id, application_reference, status, proof_of_registration_path, proof_of_funding_path, identity_document_path")
      .maybeSingle();
  } catch {
    if (uploadedPaths.length) await supabaseClient.storage.from("application-documents").remove(uploadedPaths);
    setStatus(applicationStatus, "We couldn’t save your draft. Please try again.", true);
    return false;
  }
  if (result.error || !result.data) {
    if (uploadedPaths.length) await supabaseClient.storage.from("application-documents").remove(uploadedPaths);
    setStatus(applicationStatus, "We couldn’t save your draft. Please try again.", true);
    return false;
  }
  applicationRecord = { ...applicationRecord, ...result.data };
  updateDocumentRequirements();
  setStatus(applicationStatus, "Draft saved securely.");
  return true;
}

async function resumeApplication(record) {
  if (!isVerifiedUser() || record.user_id && record.user_id !== currentUser.id) return;
  if (!await verifyCurrentStudent()) {
    setStatus(authStatus, "Your sign-in session couldn’t be verified. Please sign in again before resuming.", true);
    return;
  }
  applicationRecord = record;
  applicationForm.reset();
  applicationForm.elements.firstName.value = record.first_name || "";
  applicationForm.elements.surname.value = record.surname || "";
  applicationForm.elements.studentNumber.value = record.student_number || "";
  applicationForm.elements.email.value = currentUser.email || record.email || "";
  applicationForm.elements.phone.value = record.phone || "";
  applicationForm.elements.residence.value = record.residence_name || "";
  applicationForm.elements.moveIn.value = record.move_in_date || "";
  applicationForm.elements.roomType.value = record.room_type || "";
  updateDocumentRequirements();
  applicationForm.querySelectorAll(".form-step").forEach((section) => { section.hidden = false; });
  applicationForm.querySelector('[data-step="2"]').hidden = true;
  applicationForm.querySelector('[data-step="3"]').hidden = true;
  document.querySelector("#preview-complete").hidden = true;
  applicationFormOpen = true;
  setStatus(applicationStatus, "");
  setApplicationStep(1);
  updateAuthenticationUI();
}

grid.addEventListener("click", (event) => {
  const galleryControl = event.target.closest("[data-card-gallery-step]");
  if (galleryControl) {
    const card = galleryControl.closest(".residence-card");
    const gallery = card.querySelector(".card-gallery");
    const photoCount = gallery.children.length;
    const currentIndex = Math.round(gallery.scrollLeft / gallery.clientWidth);
    const nextIndex = (currentIndex + Number(galleryControl.dataset.cardGalleryStep) + photoCount) % photoCount;
    gallery.scrollTo({ left: nextIndex * gallery.clientWidth, behavior: "smooth" });
    return;
  }
  const button = event.target.closest("[data-open-residence]");
  if (button) {
    openResidence(button.dataset.openResidence, Number(button.dataset.photoIndex) || 0);
    return;
  }
  const card = event.target.closest(".residence-card");
  if (card && !event.target.closest("button, a, input, select")) openResidence(card.dataset.residenceName);
});
searchInput.addEventListener("input", () => {
  currentPage = 1;
  renderResidences();
});
sortSelect.addEventListener("change", () => {
  currentPage = 1;
  renderResidences();
});
loadResidences();
authenticationInitialization = initializeAuthentication();

document.addEventListener("click", (event) => {
  const directionsTrigger = event.target.closest("[data-get-directions]");
  if (directionsTrigger) {
    openDirections(
      directionsTrigger.dataset.destination,
      directionsTrigger.dataset.destinationLabel || directionsTrigger.dataset.destination,
      directionsTrigger.dataset.verifiedAddress === "true"
    );
  }
  const applyTrigger = event.target.closest("[data-open-application]");
  if (applyTrigger) {
    if (detailsDialog.open) detailsDialog.close();
    showUniversityChoice(applyTrigger.dataset.selectedResidence || "");
  }
  const universityTrigger = event.target.closest("[data-select-university]");
  if (universityTrigger) {
    const university = universityTrigger.dataset.selectUniversity;
    universityChoiceDialog.close();
    const selectedResidence = residences.some((residence) => (
      residence.name === residenceToApplyFor && residence.university === university
    )) ? residenceToApplyFor : "";
    const startNew = residenceApplicationStartNew;
    residenceToApplyFor = "";
    residenceApplicationStartNew = false;
    openApplication(selectedResidence, startNew, university);
  }
  if (event.target.closest("[data-close-dialog]")) {
    const dialog = event.target.closest("dialog");
    if (dialog) dialog.close();
  }
  if (event.target.closest("[data-close-evidence]")) evidenceDialog.close();
  if (event.target === detailsDialog || event.target === applicationDialog) event.target.close();
});
universityChoiceDialog.addEventListener("close", () => {
  residenceToApplyFor = "";
  residenceApplicationStartNew = false;
});

directionsDialog.addEventListener("close", () => {
  locationRequestId += 1;
});
retryLocationButton.addEventListener("click", requestCurrentLocation);

function setFormBusy(form, busy) {
  form.querySelectorAll("button[type='submit']").forEach((button) => { button.disabled = busy; });
}

let isSubmittingRegistration = false;
registerForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (isSubmittingRegistration) return;
  if (!registerForm.reportValidity()) return;
  const fullName = registerForm.elements.fullName.value.trim();
  const email = registerForm.elements.email.value.trim();
  const password = registerForm.elements.password.value;
  if (!fullName) {
    setStatus(authStatus, "Enter your full name to create an account.", true);
    return;
  }
  if (password !== registerForm.elements.confirmPassword.value) {
    setStatus(authStatus, "The passwords do not match.", true);
    return;
  }
  if (!supabaseClient) {
    setStatus(authStatus, supabaseUnavailableMessage, true);
    return;
  }
  isSubmittingRegistration = true;
  setFormBusy(registerForm, true);
  setStatus(authStatus, "Creating your student account…");
  let result;
  try {
    result = await supabaseClient.auth.signUp({
      email,
      password,
      options: {
        data: { full_name: fullName },
        emailRedirectTo: getAuthRedirectUrl("verify")
      }
    });
  } catch (error) {
    isSubmittingRegistration = false;
    setFormBusy(registerForm, false);
    setStatus(authStatus, getAuthErrorMessage(error), true);
    return;
  }
  isSubmittingRegistration = false;
  setFormBusy(registerForm, false);
  if (result.error) {
    setStatus(authStatus, getAuthErrorMessage(result.error), true);
    return;
  }
  if (!result.data.user || (Array.isArray(result.data.user.identities) && result.data.user.identities.length === 0)) {
    setStatus(authStatus, "We couldn’t create a new account with those details. If you already registered, sign in or reset your password.", true);
    return;
  }
  pendingVerificationEmail = email;
  verificationLinkError = false;
  showAuthDuringVerification = false;
  updateAuthenticationUI();
  setStatus(authStatus, "Check your inbox and spam folder for a verification email. Click its link to activate your account before applying.");
});

loginForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!loginForm.reportValidity()) return;
  if (!supabaseClient) {
    setStatus(authStatus, supabaseUnavailableMessage, true);
    return;
  }
  setFormBusy(loginForm, true);
  setStatus(authStatus, "Signing in securely…");
  let result;
  try {
    result = await supabaseClient.auth.signInWithPassword({
      email: loginForm.elements.email.value.trim(),
      password: loginForm.elements.password.value
    });
  } catch {
    setFormBusy(loginForm, false);
    setStatus(authStatus, "We couldn’t sign you in. Check your email and password and try again.", true);
    return;
  }
  setFormBusy(loginForm, false);
  if (result.error) {
    if (result.error.code === "email_not_confirmed" || /email not confirmed/i.test(result.error.message || "")) {
      const email = loginForm.elements.email.value.trim();
      pendingVerificationEmail = email;
      verificationLinkError = false;
      showAuthDuringVerification = false;
      updateAuthenticationUI();
      await resendVerificationEmail(email);
      return;
    }
    setStatus(authStatus, "We couldn’t sign you in. Check your email and password and try again.", true);
    return;
  }
  await handleAuthState(result.data.session, "SIGNED_IN");
  if (isVerifiedUser()) {
    applicationFormOpen = false;
    updateAuthenticationUI();
    if (pendingApplicationAfterSignIn) {
      const selectedResidence = pendingApplicationResidence;
      const university = pendingApplicationUniversity;
      const startNew = pendingApplicationStartNew;
      pendingApplicationAfterSignIn = false;
      pendingApplicationResidence = "";
      pendingApplicationUniversity = "";
      pendingApplicationStartNew = false;
      await openApplication(selectedResidence, startNew, university);
    } else {
      applicationDialog.showModal();
    }
  }
});

recoveryForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!recoveryForm.reportValidity()) return;
  setFormBusy(recoveryForm, true);
  setStatus(authStatus, "Sending password reset instructions…");
  let result;
  try {
    result = await supabaseClient.auth.resetPasswordForEmail(recoveryForm.elements.email.value.trim(), {
      redirectTo: getAuthRedirectUrl("recovery")
    });
  } catch {
    setFormBusy(recoveryForm, false);
    setStatus(authStatus, "We couldn’t send reset instructions. Please try again later.", true);
    return;
  }
  setFormBusy(recoveryForm, false);
  setStatus(authStatus, result.error
    ? "We couldn’t send reset instructions. Please try again later."
    : "If an account exists for this address, password reset instructions will arrive by email.", Boolean(result.error));
});

newPasswordForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!newPasswordForm.reportValidity()) return;
  const password = newPasswordForm.elements.password.value;
  if (password !== newPasswordForm.elements.confirmPassword.value) {
    setStatus(authStatus, "The passwords do not match.", true);
    return;
  }
  setFormBusy(newPasswordForm, true);
  setStatus(authStatus, "Updating your password…");
  let result;
  try {
    result = await supabaseClient.auth.updateUser({ password });
  } catch {
    setFormBusy(newPasswordForm, false);
    setStatus(authStatus, "We couldn’t update your password. Request a new password reset link and try again.", true);
    return;
  }
  setFormBusy(newPasswordForm, false);
  if (result.error) {
    setStatus(authStatus, "We couldn’t update your password. Request a new password reset link and try again.", true);
    return;
  }
  passwordRecoveryInProgress = false;
  setAuthView("login");
  await handleAuthState(result.data.user ? { user: result.data.user } : currentSession, "USER_UPDATED");
  if (isVerifiedUser()) {
    applicationDialog.showModal();
    setStatus(authStatus, "Your password has been updated. You’re signed in securely.");
  } else {
    setStatus(authStatus, "Your password has been updated. You can now sign in.");
  }
});

async function resendVerificationEmail(email = document.querySelector("#verification-change-email").value.trim()) {
  const button = document.querySelector("#resend-verification");
  if (!email || !document.querySelector("#verification-change-email").checkValidity()) {
    document.querySelector("#verification-change-email").reportValidity();
    return false;
  }
  let cooldown = 0;
  try {
    cooldown = Number(sessionStorage.getItem(`vsh-verification-resend:${email.toLowerCase()}`) || 0);
  } catch {
    setStatus(authStatus, "Your browser could not check the resend cooldown. Please wait before trying again.", true);
    return false;
  }
  if (Date.now() < cooldown) {
    setStatus(authStatus, "A verification email was requested recently. Please check your inbox and spam folder before trying again.", true);
    return false;
  }
  button.disabled = true;
  setStatus(authStatus, "Requesting a new verification email…");
  let result;
  try {
    result = await supabaseClient.auth.resend({
      type: "signup",
      email,
      options: { emailRedirectTo: getAuthRedirectUrl("verify") }
    });
  } catch (error) {
    button.disabled = false;
    setStatus(authStatus, getAuthErrorMessage(error, "request a verification email"), true);
    return false;
  }
  if (result.error) {
    button.disabled = false;
    setStatus(authStatus, getAuthErrorMessage(result.error, "request a verification email"), true);
    return false;
  }
  const cooldownUntil = Date.now() + 60000;
  try {
    sessionStorage.setItem(`vsh-verification-resend:${email.toLowerCase()}`, String(cooldownUntil));
  } catch {
    setStatus(authStatus, "If your account needs verification, a new email has been requested. Check your inbox and spam folder.");
  }
  let remaining = 60;
  setStatus(authStatus, "If your account needs verification, a new email has been requested. Check your inbox and spam folder.");
  const timer = window.setInterval(() => {
    remaining -= 1;
    if (remaining <= 0) {
      window.clearInterval(timer);
      button.disabled = false;
      button.textContent = "Resend verification email";
    } else {
      button.textContent = `Resend available in ${remaining}s`;
    }
  }, 1000);
  return true;
}

document.querySelector("#resend-verification").addEventListener("click", () => {
  resendVerificationEmail();
});

document.querySelector("#sign-out").addEventListener("click", async () => {
  const button = document.querySelector("#sign-out");
  button.disabled = true;
  setStatus(authStatus, "Signing out…");
  try {
    const result = await supabaseClient.auth.signOut();
    if (result.error) throw result.error;
  } catch {
    button.disabled = false;
    setStatus(authStatus, "We couldn’t sign you out. Please try again.", true);
    return;
  }
  currentUser = null;
  currentSession = null;
  applicationRecord = null;
  applicationSuccessPanel.hidden = true;
  applicationFormOpen = false;
  pendingApplicationAfterSignIn = false;
  pendingApplicationResidence = "";
  pendingApplicationUniversity = "";
  pendingApplicationStartNew = false;
  applicationForm.reset();
  setAuthView("login");
  updateAuthenticationUI();
  button.disabled = false;
});

document.querySelectorAll("[data-auth-view]").forEach((button) => {
  button.addEventListener("click", () => {
    if (button.dataset.authView === "register" && pendingVerificationEmail) {
      document.querySelector("#register-email").value = pendingVerificationEmail;
      document.querySelector("#register-password").value = "";
      document.querySelector("#register-confirm-password").value = "";
      showAuthDuringVerification = true;
      updateAuthenticationUI();
    } else if (button.dataset.authView === "login") {
      document.querySelector("#login-email").value = pendingVerificationEmail
        || document.querySelector("#verification-change-email").value.trim();
      showAuthDuringVerification = true;
      updateAuthenticationUI();
    }
    setAuthView(button.dataset.authView);
  });
});
document.querySelector("#new-application").addEventListener("click", () => {
  pendingApplicationAfterSignIn = false;
  if (applicationDialog.open) applicationDialog.close();
  showUniversityChoice("", true);
});

applicationForm.addEventListener("click", async (event) => {
  const nextButton = event.target.closest(".form-next");
  if (nextButton) {
    const step = Number(nextButton.closest(".form-step").dataset.step);
    setStatus(applicationStatus, "");
    if (step === 1) {
      const fields = [...applicationForm.querySelectorAll(`[data-step="${step}"] input, [data-step="${step}"] select`)];
      const firstInvalid = fields.find((field) => field.type !== "file" && !field.checkValidity());
      if (firstInvalid) {
        setStatus(applicationStatus, `Please complete ${firstInvalid.labels[0]?.textContent.trim() || "all required details"} before continuing.`, true);
        firstInvalid.reportValidity();
        return;
      }
      if (await saveApplicationDraft()) setApplicationStep(2);
      return;
    }

    const requiredFields = ["firstName", "surname", "studentNumber", "email", "phone", "residence", "moveIn"]
      .map((name) => applicationForm.elements[name]);
    const firstInvalid = requiredFields.find((field) => !field.checkValidity());
    if (firstInvalid) {
      setApplicationStep(Number(firstInvalid.closest(".form-step").dataset.step));
      setStatus(applicationStatus, `Please complete ${firstInvalid.labels[0]?.textContent.trim() || "the required application details"} before reviewing.`, true);
      firstInvalid.reportValidity();
      return;
    }

    for (const item of documentFields) {
      const file = applicationForm.elements[item.input].files[0];
      if (file && !await validateDocumentFile(file, item.label)) return;
    }

    const missingDocuments = documentFields.filter((item) => {
      const file = applicationForm.elements[item.input].files[0];
      return (!file || !file.size) && !applicationRecord?.[item.column];
    });
    if (missingDocuments.length) {
      setStatus(applicationStatus, `Upload the following required documents before reviewing: ${missingDocuments.map((item) => item.label).join(", ")}.`, true);
      applicationForm.elements[missingDocuments[0].input].focus();
      return;
    }

    updateReview();
    setApplicationStep(3);
    return;
  }

  const backButton = event.target.closest(".form-back");
  if (backButton) {
    setStatus(applicationStatus, "");
    setApplicationStep(Number(backButton.closest(".form-step").dataset.step) - 1);
  }
});

async function sendApplicationNotifications(applicationId) {
  const status = document.querySelector("#notification-status");
  const retryButton = document.querySelector("#retry-application-notifications");
  retryButton.disabled = true;
  setStatus(status, "Sending your confirmation email…");
  let result;
  try {
    result = await supabaseClient.functions.invoke(
      "notify-application-submission",
      { body: { applicationId } }
    );
  } catch {
    setStatus(status, "Your application was received, but the confirmation email could not be sent yet. Retry the email here; do not submit another application.", true);
    retryButton.hidden = false;
    retryButton.disabled = false;
    return false;
  }
  const { data, error } = result;
  if (error || !data) {
    setStatus(status, "Your application was received, but the confirmation email could not be confirmed. Retry the email here; do not submit another application.", true);
    retryButton.hidden = false;
    retryButton.disabled = false;
    return false;
  }

  const notifications = Array.isArray(data.notifications) ? data.notifications : [];
  const studentConfirmation = notifications.find((notification) => notification.type === "student_confirmation");
  const managementAlert = notifications.find((notification) => notification.type === "management_alert");
  const confirmationSent = ["sent", "already_sent"].includes(studentConfirmation?.status);
  const managementAlertSent = ["sent", "already_sent"].includes(managementAlert?.status);
  const confirmationPreview = managementAlert?.status === "skipped_test_mode";
  if (!confirmationSent) {
    const retriesExhausted = studentConfirmation?.status === "retry_limit_reached";
    setStatus(
      status,
      retriesExhausted
        ? "Your application was received, but the confirmation email could not be sent after several attempts. Please contact Student Heights; do not submit another application."
        : "Your application was received, but the confirmation email could not be sent yet. Retry the email here; do not submit another application.",
      true
    );
    retryButton.hidden = retriesExhausted;
    retryButton.disabled = false;
    return false;
  }

  setStatus(
    status,
    confirmationPreview
      ? "Test mode: the application confirmation email was accepted by Resend for the configured preview inbox. No email was sent to the applicant."
      : managementAlertSent
      ? "The confirmation email and management notification were accepted by the email provider."
      : managementAlert?.status === "retry_limit_reached"
        ? "The confirmation email was accepted by the email provider. The management notification could not be sent after several attempts."
        : "The confirmation email was accepted by the email provider. The management notification could not be sent yet."
  );
  retryButton.hidden = confirmationPreview || managementAlertSent || managementAlert?.status === "retry_limit_reached";
  retryButton.disabled = false;
  return confirmationSent && (managementAlertSent || confirmationPreview);
}

async function getConfirmedSubmittedApplication(applicationId) {
  try {
    return await supabaseClient
      .from("applications")
      .select("id, user_id, application_reference, status, first_name, surname, student_number, email, residence_name, room_type, move_in_date, submitted_at")
      .eq("id", applicationId)
      .eq("user_id", currentUser.id)
      .maybeSingle();
  } catch (error) {
    return { data: null, error };
  }
}

function isSubmittedApplication(application) {
  return Boolean(application?.submitted_at)
    && ["submitted", "under_review", "approved", "rejected"].includes(application.status);
}

function showApplicationSubmissionSuccess(application) {
  applicationRecord = { ...applicationRecord, ...application };
  updateEvidenceCard(applicationRecord);
  const selectedResidence = residences.find((residence) => residence.name === applicationRecord.residence_name);
  const university = universityDirectory[selectedResidence?.university || selectedApplicationUniversity];
  const statusLabel = ({
    submitted: "Pending Management Approval",
    under_review: "Under Management Review",
    approved: "Approved",
    rejected: "Not Approved"
  })[applicationRecord.status] || "Status unavailable";
  const successCopy = ({
    submitted: "Your application has been received and is awaiting management approval. Your application reference is displayed below. A confirmation email will be sent to your registered email address.",
    under_review: "Your application has been received and is under management review. Your application reference is displayed below. A confirmation email will be sent to your registered email address.",
    approved: "Your application has been received and management has approved it. Your application reference is displayed below. A confirmation email will be sent to your registered email address.",
    rejected: "Your application has been received and management has updated its status. Your application reference is displayed below. A confirmation email will be sent to your registered email address."
  })[applicationRecord.status] || "Your application has been received. Your application reference is displayed below.";
  document.querySelector("#submission-success-copy").textContent = successCopy;
  document.querySelector("#submission-reference").textContent = applicationRecord.application_reference;
  document.querySelector("#submission-university").textContent = university?.name || "University not available";
  document.querySelector("#submission-residence").textContent = applicationRecord.residence_name;
  document.querySelector("#submission-status").textContent = statusLabel;
  applicationForm.querySelectorAll(".form-step").forEach((section) => { section.hidden = true; });
  setStatus(applicationStatus, "");
  setStatus(
    document.querySelector("#notification-status"),
    "A confirmation email is being sent to your registered email address."
  );
  document.querySelector("#retry-application-notifications").hidden = true;
  applicationSuccessPanel.hidden = false;
  applicationFormOpen = false;
  updateAuthenticationUI();
}

applicationForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const values = new FormData(applicationForm);
  const requiredValues = ["firstName", "surname", "studentNumber", "email", "phone", "residence", "moveIn"];
  if (requiredValues.some((name) => !String(values.get(name) || "").trim())) {
    setStatus(applicationStatus, "Complete all required fields before submitting.", true);
    return;
  }
  const missingDocument = documentFields.find((item) => {
    const file = values.get(item.input);
    return !(file instanceof File && file.size) && !applicationRecord?.[item.column];
  });
  if (missingDocument) {
    setStatus(applicationStatus, `Please upload your ${missingDocument.label.toLowerCase()} before submitting.`, true);
    return;
  }
  if (!applicationForm.reportValidity()) return;

  if (!await verifyCurrentStudent()) {
    return;
  }

  if (isSubmittingApplication) return;
  isSubmittingApplication = true;
  const submitButton = applicationForm.querySelector("button[type='submit']");
  submitButton.disabled = true;
  setStatus(applicationStatus, "Submitting your application…");

  const previousSubmission = await getConfirmedSubmittedApplication(applicationRecord.id);
  if (previousSubmission.error) {
    isSubmittingApplication = false;
    submitButton.disabled = false;
    setStatus(applicationStatus, "We could not verify your application status. Your saved draft is unchanged; check My Applications before trying again.", true);
    return;
  }
  if (isSubmittedApplication(previousSubmission.data)) {
    showApplicationSubmissionSuccess(previousSubmission.data);
    await sendApplicationNotifications(applicationRecord.id);
    isSubmittingApplication = false;
    submitButton.disabled = false;
    applicationForm.querySelectorAll(".form-step input, .form-step select, .form-step button").forEach((element) => { element.disabled = true; });
    await loadStudentApplications();
    updateAuthenticationUI();
    return;
  }

  if (!await saveApplicationDraft()) {
    isSubmittingApplication = false;
    submitButton.disabled = false;
    return;
  }
  let result;
  try {
    result = await supabaseClient
      .rpc("submit_student_application", {
        p_application_id: applicationRecord.id,
        p_privacy_consent: values.get("consent") === "on"
      });
  } catch (error) {
    result = { data: null, error };
  }

  const confirmation = await getConfirmedSubmittedApplication(applicationRecord.id);
  if (confirmation.error) {
    isSubmittingApplication = false;
    submitButton.disabled = false;
    setStatus(applicationStatus, "We could not verify whether submission completed. Your application was not confirmed here; check My Applications before retrying, and do not start another application.", true);
    return;
  }
  if (!isSubmittedApplication(confirmation.data)) {
    isSubmittingApplication = false;
    submitButton.disabled = false;
    setStatus(applicationStatus, getApplicationSubmissionErrorMessage(result.error), true);
    return;
  }

  showApplicationSubmissionSuccess(confirmation.data);
  await sendApplicationNotifications(applicationRecord.id);
  isSubmittingApplication = false;
  submitButton.disabled = false;
  applicationForm.querySelectorAll(".form-step input, .form-step select, .form-step button").forEach((element) => { element.disabled = true; });
  await loadStudentApplications();
  updateAuthenticationUI();
});

document.querySelector("#view-application-status").addEventListener("click", async () => {
  applicationSuccessPanel.hidden = true;
  applicationFormOpen = false;
  updateAuthenticationUI();
  await loadStudentApplications();
});

document.querySelector("#retry-application-notifications").addEventListener("click", async (event) => {
  if (!applicationRecord?.id || !isSubmittedApplication(applicationRecord)) return;
  const button = event.currentTarget;
  button.disabled = true;
  await sendApplicationNotifications(applicationRecord.id);
});

document.querySelector("#open-evidence-card").addEventListener("click", () => {
  evidenceDialog.showModal();
});
document.querySelector("#print-evidence-card").addEventListener("click", () => {
  document.body.classList.add("printing-evidence-card");
  window.print();
});
window.addEventListener("afterprint", () => {
  document.body.classList.remove("printing-evidence-card");
});
evidenceDialog.addEventListener("close", () => {
  document.body.classList.remove("printing-evidence-card");
});

const menuToggle = document.querySelector(".menu-toggle");
const primaryNav = document.querySelector("#primary-nav");
menuToggle.addEventListener("click", () => {
  const isOpen = menuToggle.getAttribute("aria-expanded") === "true";
  menuToggle.setAttribute("aria-expanded", String(!isOpen));
  menuToggle.setAttribute("aria-label", isOpen ? "Open navigation" : "Close navigation");
  primaryNav.classList.toggle("open", !isOpen);
});
primaryNav.addEventListener("click", (event) => {
  if (event.target.closest("a") && !event.target.closest(".button")) {
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.setAttribute("aria-label", "Open navigation");
    primaryNav.classList.remove("open");
  }
});

function setAssistantOpen(open) {
  assistantPanel.hidden = !open;
  document.querySelector("#assistant-launcher").hidden = open;
  if (open) document.querySelector("#assistant-input").focus();
}
document.querySelector("#assistant-launcher").addEventListener("click", () => setAssistantOpen(true));
document.querySelector("#close-assistant").addEventListener("click", () => setAssistantOpen(false));
document.querySelectorAll("[data-open-assistant]").forEach((button) => button.addEventListener("click", () => setAssistantOpen(true)));

function addAssistantMessage(text, className) {
  const message = document.createElement("p");
  message.className = className;
  message.textContent = text;
  assistantMessages.append(message);
  assistantMessages.scrollTop = assistantMessages.scrollHeight;
}

function replyToQuestion(question) {
  const lower = question.toLocaleLowerCase();
  if (/\b(map|direction|where|location)\b/.test(lower)) {
    const residence = residences.find((item) => lower.includes(item.name.toLocaleLowerCase()));
    const message = document.createElement("p");
    message.className = "assistant-bubble";
    message.append(
      residence
        ? `I can make a route from your current location to ${residence.name}. The street address isn’t verified, so confirm the map pin before travelling. `
        : "I can make a route from your current location to Bedworth Park. For a residence, check its details first because street addresses aren’t verified. "
    );
    const button = document.createElement("button");
    button.type = "button";
    button.className = "assistant-directions";
    button.dataset.getDirections = "";
    button.dataset.destination = residence?.address || residence?.name || "Bedworth Park";
    button.dataset.destinationLabel = residence?.name || "Bedworth Park";
    button.dataset.verifiedAddress = String(Boolean(residence?.address));
    button.textContent = `Get directions to ${residence?.name || "Bedworth Park"} ↗`;
    message.append(button);
    assistantMessages.append(message);
    assistantMessages.scrollTop = assistantMessages.scrollHeight;
    return;
  }
  if (/\b(apply|application|form|submit)\b/.test(lower)) {
    addAssistantMessage("Use “Start an application” to sign in with an email link and submit your details to residence management. Submission does not guarantee a room or allocation.", "assistant-bubble");
    return;
  }
  if (/\b(document|documents|requirement|requirements)\b/.test(lower)) {
    addAssistantMessage("The official document checklist has not been provided. Please confirm required documents with residence management before applying.", "assistant-bubble");
    return;
  }
  if (/\b(opening|open date|when|status|available|availability)\b/.test(lower)) {
    addAssistantMessage("I don’t have published application dates, verified availability, or access to private application records. Please confirm current information with residence management.", "assistant-bubble");
    return;
  }
  const match = residences.find((residence) => lower.includes(residence.name.toLocaleLowerCase()));
  if (match) {
    addAssistantMessage(`${match.name} is in the residence directory. Open its details card to see the supplied photos and search directions. Room and availability information has not been provided.`, "assistant-bubble");
    return;
  }
  if (/\b(residence|residences|find|search)\b/.test(lower)) {
    addAssistantMessage(`There are ${residences.length} named residences in this directory. Use the search field to filter by name. Availability and room types are not published here.`, "assistant-bubble");
    return;
  }
  addAssistantMessage("I can help search the residence names, explain the application process, or find directions to Bedworth Park. What would you like to know?", "assistant-bubble");
}

document.querySelector("#assistant-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const input = document.querySelector("#assistant-input");
  const question = input.value.trim();
  if (!question) return;
  addAssistantMessage(question, "user-bubble");
  input.value = "";
  replyToQuestion(question);
});
