# Vaal Student Hive

This is the existing static HTML, CSS, and browser-JavaScript website. A small Node.js build step injects the browser-safe Supabase project URL and publishable key into the generated `dist/config.js`; it does not bundle or redesign the frontend.

## Local setup

1. Install Node.js 18 or newer.
2. Copy `.env.example` to `.env`:

   ```powershell
   Copy-Item .env.example .env
   ```

3. The project URL and public publishable key for Supabase project `iklpdshgmrtkkufwcbfv` are configured as safe frontend defaults. You can override them with `SUPABASE_URL` and `SUPABASE_PUBLISHABLE_KEY` in `.env` or the build environment. Remote URLs other than this project's URL are rejected. Never put a `service_role` key in `.env` or frontend code.
4. Run:

   ```powershell
   npm run dev
   ```

5. Open the local URL printed by the command (default `http://127.0.0.1:4173`).

There are no npm runtime dependencies. The build uses Node.js built-in modules and writes the deployable static files to `dist/`. You do not need Node.js installed locally to deploy through Vercel; Vercel runs the configured build in its hosted environment.

If sign-in reports Supabase is unavailable, first check that the Supabase client script loaded and that the deployed app includes the current configuration fallback. The publishable key is intended for browser use; a service-role key is not.

## Supabase setup

1. In Supabase Authentication settings, enable email/password sign-in and require email confirmation.
2. Set the Site URL to `https://student-heights.vercel.app/`. Add `https://student-heights.vercel.app/?auth=verify` and `https://student-heights.vercel.app/?auth=recovery` to the allowed redirect URLs in Authentication > URL Configuration. Add local and any Vercel preview origins used for testing as needed.
3. Configure SMTP if you need reliable email delivery beyond Supabase's default email sending limits.
4. In Supabase Dashboard, open Authentication > Email Templates > Confirm signup. Set the subject to `Verify Your Student Heights Account` and paste the HTML from `supabase/email-templates/confirm-signup.html` into the message body. Keep `{{ .ConfirmationURL }}` unchanged in both links. Signup passes the root of the current website origin with `?auth=verify` as `emailRedirectTo`; Supabase uses it after confirmation when the URL is in the redirect allow list.
5. Supabase's hosted Auth template is configured in the dashboard and is not deployed by the static-site build. Its template editor accepts an HTML body; this setup does not provide a separate configurable plain-text body.
6. Review `supabase/setup.sql` against the current live schema and data before running it in the Supabase SQL Editor. It is a setup script that alters/creates objects; it has not been executed or tested against your hosted project.
7. Management access is based on the trusted `app_metadata.role = "management"` claim. Assign that claim through a trusted Supabase administrative process, never from browser-provided user metadata.
8. The `application-documents` bucket is private. Review the bucket and Storage policies in the SQL script before accepting real student documents.

The frontend supports student sign-up, confirmation, login, recovery, verified-session gating, application drafts/status, and private document uploads. Browser sessions are persisted; the site explicitly exchanges the existing confirmation callback for a session, waits for initial session restoration before handling Apply, and returns signed-out applicants to their requested application after sign-in. Apply resumes an existing draft or displays an existing application status before offering a separately requested new application. The signup confirmation template is separate from the application-submission notifications described below. Database and storage enforcement depends on the reviewed SQL policies actually being installed in the connected Supabase project.

### Application email notifications (Resend)

After a student submission is confirmed, the student page calls `notify-application-submission`. The function verifies the signed-in student's verified email and application ownership, sends the confirmation to the account email, and sends a separate new-application alert to the configured management inbox. Management status changes call `notify-application-status`, which verifies the management role and sends the status email only to the student's verified account email. Both functions use the service-only delivery log to avoid duplicate notices and limit retries. Provider acceptance is not a guarantee of inbox delivery.

This workspace contains the Edge Function sources at `supabase/functions/notify-application-submission/index.ts` and `supabase/functions/notify-application-status/index.ts`, the shared status email template at `supabase/functions/_shared/status-email-template.ts`, and the additive database setup script at `supabase/email-notifications.sql`. They have not been deployed or executed. You can configure the email backend in Supabase and Resend without installing Node.js or Supabase CLI:

1. Confirm in the Supabase Dashboard that the existing `public.applications` table has the columns referenced by the function (`id`, `user_id`, `application_reference`, `status`, `first_name`, `surname`, `student_number`, `email`, `residence_name`, `room_type`, `move_in_date`, and `submitted_at`). Do not run the script if this project has a different schema; inspect and adapt it first.
2. In Supabase Dashboard > SQL Editor, review and run `supabase/email-notifications.sql`. It only adds the delivery-log table and two restricted service-role RPCs; it does not recreate application or residence tables. Do not run it until the existing schema has been confirmed.
3. For an email preview before buying a domain, create a Resend API key and use Resend's test sender `onboarding@resend.dev`. Resend test sending is limited to the email address associated with your Resend account; it is not applicant delivery.
4. In Supabase Dashboard > Edge Functions, create and deploy `notify-application-submission` using its source file. Keep JWT verification enabled. This dashboard deployment does not require Node.js or Supabase CLI on your computer.
5. In this function's secrets/settings, set `RESEND_API_KEY`, `ALLOWED_ORIGINS`, `RESEND_TEST_MODE=true`, and `RESEND_TEST_RECIPIENT` to the email address associated with your Resend account. In this test mode, the function forces the sender to `onboarding@resend.dev`, sends only the application-confirmation preview to `RESEND_TEST_RECIPIENT`, and skips the management alert. The applicant receives no email. Do not put secrets in frontend code. Supabase supplies `SUPABASE_URL`, `SUPABASE_ANON_KEY`, and `SUPABASE_SERVICE_ROLE_KEY` to Edge Functions; never copy the service-role key into the website.
6. Before real applicant email delivery, verify a domain you own in Resend, set `RESEND_TEST_MODE=false`, and configure `RESEND_FROM_EMAIL` to an address on that verified domain. Keep `MANAGEMENT_NOTIFICATION_EMAIL` set to the management inbox. The status-notification function must also be deployed before enabling real status emails.
7. The frontend has a public Supabase URL/key fallback, so Vercel environment variables are optional for this project's normal deployment. Redeploy the latest source; never use the service-role key for the frontend.
8. Test only with an account/application explicitly designated for testing. Confirm the row is submitted before invoking the function, inspect Edge Function logs and delivery-log rows, and check Resend's email logs. Provider acceptance is not proof of inbox delivery. Do not test against a real student's application without permission.

### Management dashboard contract

Open the management workspace at `/management`. The build publishes it alongside the student site and it uses the same Supabase project configuration. Management users sign in with email and password and must have the trusted `app_metadata.role = "management"` claim.

The student site and management dashboard must use the same Supabase project. The shared integration objects are `public.residences`, `public.applications`, and the private `application-documents` Storage bucket. Management users need the trusted `app_metadata.role = "management"` claim.

The dashboard can read application rows under the management RLS policy. For status changes, call the `management_set_application_status` RPC with `p_application_id` and `p_status` (`under_review`, `approved`, or `rejected`); direct table updates to `status` are not granted to browser clients. The student site submits through `submit_student_application(p_application_id, p_privacy_consent)` and the RPC records the consent timestamp. To access uploaded documents, management must use an authenticated session and the private bucket's authorized read policy (for example, create short-lived signed URLs); do not make the bucket public.

The residence seed at the end of `supabase/setup.sql` adds missing directory rows without replacing existing residence names, photos, or availability when the script is run again.

## Build and deployment

For Vercel, [vercel.json](./vercel.json) configures the Build Command as `npm run build` and Output Directory as `dist`. Set `SUPABASE_URL` to `https://iklpdshgmrtkkufwcbfv.supabase.co` and `SUPABASE_PUBLISHABLE_KEY` to the matching publishable/anon key in the project's environment variables for Production and Preview (and Development if used). Redeploy after updating them. The build injects these values into the public `dist/config.js`; do not remove `package.json` or the build script.

The frontend is static; email delivery runs in Supabase Edge Functions, not in the browser. The hosting provider does not need the service-role key.

Local production build:

```powershell
npm run build
```

Only the URL and publishable key are emitted into the browser-visible `dist/config.js`; they are public client configuration, not secrets. The service-role key must not be added to these variables.
